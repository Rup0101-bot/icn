/* Reuse the same penalty content as the full explorer. */
(function () {
  'use strict';
  var host = document.getElementById('homePenaltyExplorer');
  if (!host || !window.SITE || !window.SITE.penalties) return;
  var data = window.SITE.penalties;
  var palette = ['#22d3ee','#a78bfa','#fb7185','#fbbf24','#34d399'];
  var labels = ['Security safeguards','Breach notification',"Children’s data",'SDF obligations','Other breaches'];
  function esc(s){return String(s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  function point(r,a){var t=a*Math.PI/180;return [(220+r*Math.cos(t)).toFixed(3),(220+r*Math.sin(t)).toFixed(3)];}
  function arc(start,end){var a=point(174,start),b=point(174,end),c=point(119,end),d=point(119,start);return 'M'+a+' A174 174 0 0 1 '+b+' L'+c+' A119 119 0 0 0 '+d+' Z';}
  host.innerHTML='<div class="penalty-wheel-side"><svg class="penalty-wheel" viewBox="0 0 440 440" role="group" aria-label="Five clickable penalty categories">'+
    '<circle cx="220" cy="220" r="196" fill="none" stroke="#fff" stroke-opacity=".08"/>'+data.map(function(p,i){
      return '<path class="penalty-segment" d="'+arc(-90+i*72+5,-90+(i+1)*72-5)+'" fill="'+palette[i]+'" data-penalty="'+i+'" tabindex="0" role="button" aria-controls="homePenaltyDetail" aria-pressed="false" aria-label="'+esc(labels[i])+', up to '+p.amountCr+' crore"><title>'+esc(labels[i])+' · up to ₹'+p.amountCr+' cr</title></path>';
    }).join('')+'<circle cx="220" cy="220" r="103" fill="#0a1633" stroke="#35456b"/><text x="220" y="190" text-anchor="middle" fill="#93a5cc" font-size="11" letter-spacing="2">UP TO</text><text id="penaltyWheelAmount" x="220" y="234" text-anchor="middle" fill="white" font-size="36" font-weight="800"></text><text x="220" y="261" text-anchor="middle" fill="#cbd5e1" font-size="12">statutory maximum</text></svg><div class="penalty-category-list" aria-label="Choose a penalty category">'+data.map(function(p,i){return '<button type="button" data-penalty="'+i+'" aria-controls="homePenaltyDetail" aria-pressed="false" style="--pen-color:'+palette[i]+'"><span class="penalty-color-dot"></span><span>'+esc(labels[i])+'</span><b>₹'+p.amountCr+' cr</b></button>';}).join('')+'</div></div><div class="penalty-detail" id="homePenaltyDetail" aria-live="polite" aria-atomic="true"></div>';
  var selected=0;
  function choose(index){
    selected=index;var p=data[index];
    host.querySelectorAll('[data-penalty]').forEach(function(el){var active=Number(el.dataset.penalty)===index;el.setAttribute('aria-pressed',String(active));el.classList.toggle('is-selected',active);});
    host.querySelector('#penaltyWheelAmount').textContent='₹'+p.amountCr+' cr';
    var detail=host.querySelector('#homePenaltyDetail');detail.style.setProperty('--pen-color',palette[index]);
    detail.innerHTML='<span class="penalty-detail-kicker">CATEGORY '+(index+1)+' / '+data.length+'</span><p class="penalty-detail-amount">Up to ₹'+p.amountCr+' <span>crore</span></p><h3>'+esc(p.title)+'</h3><p>'+esc(p.text)+'</p><div class="penalty-context"><strong>Keep it in context</strong><p>A listed maximum is not a predicted or automatic fine. A breach alone does not prove safeguards were inadequate.</p></div><a class="btn btn-primary" href="penalties.html">Explore categories &amp; sector examples →</a><a class="penalty-readiness-link" href="readiness.html#assessment">Find your readiness gaps →</a>';
  }
  host.querySelectorAll('[data-penalty]').forEach(function(el){
    el.addEventListener('click',function(){choose(Number(el.dataset.penalty));});
    el.addEventListener('keydown',function(e){
      if(e.key==='Enter'||e.key===' '){e.preventDefault();choose(Number(el.dataset.penalty));}
      if(e.key==='ArrowRight'||e.key==='ArrowLeft'){e.preventDefault();var next=(selected+(e.key==='ArrowRight'?1:-1)+data.length)%data.length;choose(next);host.querySelector('.penalty-category-list [data-penalty="'+next+'"]').focus();}
    });
  });
  choose(0);
})();
