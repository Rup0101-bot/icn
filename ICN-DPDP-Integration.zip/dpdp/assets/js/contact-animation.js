/* Decorative contact animation with a persistent user pause control. */
(function () {
  var scene = document.querySelector('.cyber-loop');
  if (!scene) return;
  var button = scene.querySelector('.cyber-motion-toggle');
  var reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
  var paused = reduced.matches;
  function update() {
    scene.classList.toggle('is-paused', paused);
    button.setAttribute('aria-pressed', String(paused));
    button.textContent = paused ? 'Play animation' : 'Pause animation';
  }
  button.addEventListener('click', function () { paused = !paused; update(); });
  reduced.addEventListener('change', function (event) { paused = event.matches; update(); });
  update();
})();
