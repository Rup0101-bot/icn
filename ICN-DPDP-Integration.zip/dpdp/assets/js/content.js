/* =====================================================================
   CYBER CIBIL — DPDP website content collection
   ---------------------------------------------------------------------
   This ONE file holds every editable string on the site: company
   details, legal facts, source links, commencement dates, timeline,
   sector examples, penalty data, services, FAQs and the assessment.

   HOW TO EDIT
   - Replace every [PLACEHOLDER IN BRACKETS] with your real content.
     Anything still wrapped in [BRACKETS] renders as a visible,
     dashed-underline placeholder on the site until you replace it.
   - To update legal facts after a new notification: edit `legal`,
     `timeline` and `lastVerified`, then re-verify against the
     official sources listed in `sources`.
   - Dates use the format "13 May 2027" for display and ISO
     (2027-05-13) for sorting where a field asks for it.

   LEGAL CONTENT IS VERIFIED AGAINST OFFICIAL SOURCES. Re-verify
   before publication and update `lastVerified`.
   ===================================================================== */

window.SITE = {

  /* ---------------------------------------------------------------
     1. COMPANY DETAILS — the main editable placeholders
     --------------------------------------------------------------- */
  company: {
    name: "CYBER CIBIL",
    tagline: "DPDP compliance services in India",
    // Optional logo image. Leave as-is to use the built-in mark.
    logoSrc: "",
    logoAlt: "CYBER CIBIL",
    // Booking page (Calendly / Cal.com / your own page).
    bookingLink: "resources.html#contact",
    contact: {
      email: "info@icn3.com",
      website: "https://icn3.com/",
      phone: "+918777628651",
      address: "Kolkata, West Bengal"
    },
    // Short "why us" copy. Keep it factual. Do NOT invent clients,
    // certifications, testimonials or regulatory endorsements.
    aboutBlurb: "CYBER CIBIL provides advisory, technical assessment, and governance workflows to help Indian enterprises navigate the Digital Personal Data Protection Act with complete clarity.",
    // Proof slot: only add real, permissioned proof (case studies,
    // client logos, metrics). Deliberately a placeholder by default.
    clientProof: "Case studies and enterprise compliance milestones are shared under mutual non-disclosure and published here only with explicit permission."
  },

  /* ---------------------------------------------------------------
     2. VERIFICATION & KEY DATES — update these when facts change
     --------------------------------------------------------------- */
  lastVerified: "25 September 2026",
  lastVerifiedISO: "2026-09-25",

  legal: {
    mainDutiesDate: "13 May 2027",       // phase (c) commencement
    mainDutiesISO: "2027-05-13",
    consentManagerDate: "13 November 2026", // phase (b) commencement
    phaseOneDate: "13 November 2025",     // phase (a) commencement
    rulesNotified: "13 November 2025"     // DPDP Rules, 2025 notified
  },

  sources: {
    act: {
      label: "DPDP Act, 2023 — full text (India Code)",
      url: "https://www.indiacode.nic.in/bitstream/123456789/22037/2/a2023-22.pdf",
      note: "Act No. 22 of 2023, including the penalty Schedule."
    },
    commencement: {
      label: "Commencement notification, G.S.R. 843(E) (eGazette)",
      url: "https://egazette.gov.in/WriteReadData/2025/267647.pdf",
      note: "Dated 13 November 2025 — brings the Act into force in phases."
    },
    rules: {
      label: "DPDP Rules, 2025 — G.S.R. 846(E) (MeitY)",
      url: "https://www.meity.gov.in/static/uploads/2025/11/53450e6e5dc0bfa85ebd78686cadad39.pdf",
      note: "Notified 13 November 2025 with phased commencement."
    },
    meity: {
      label: "MeitY / PIB statements on implementation",
      url: "https://www.pib.gov.in/PressReleasePage.aspx?PRID=2261823&lang=1&reg=3",
      note: "Official statements; MeitY has confirmed full enforceability from 13 May 2027."
    }
  },

  /* ---------------------------------------------------------------
     3. HOME PAGE
     --------------------------------------------------------------- */
  home: {
    heroKicker: "Digital Personal Data Protection Act, 2023",
    heroTitle: "Make data protection understandable. Make readiness actionable.",
    heroSub: "CYBER CIBIL helps Indian businesses read the DPDP Act without jargon, see what it means for their sector, and build readiness step by step — before the main duties commence on 13 May 2027.",
    heroCaption: "Personal data works best when it flows through consent, security and rights controls — not around them.",
    stats: [
      { value: "13 May 2027", label: "Main duties and the penalty regime are scheduled to commence", href: "timeline.html" },
      { value: "₹250 cr", label: "Highest statutory maximum in the Act's penalty Schedule", href: "penalties.html" },
      { value: "5", label: "Penalty categories set by violation type — not by sector", href: "penalties.html", count: true },
      { value: "6", label: "Sector guides: BFSI, healthcare, e-commerce, education, SaaS, HR", href: "sectors.html", count: true }
    ],
    pillars: [
      {
        icon: "book",
        title: "Understand the law",
        text: "Plain-English guides to who the Act covers, consent and legitimate uses, rights, security safeguards, breach response and children's data — each linked to the official source."
      },
      {
        icon: "map",
        title: "See your sector clearly",
        text: "Illustrated data-flow guides for BFSI, healthcare, e-commerce, education, SaaS and HR — with illustrative failure scenarios and the duties they touch."
      },
      {
        icon: "workflow",
        title: "Turn readiness into routine",
        text: "A five-step journey from data discovery to monitoring, plus a self-assessment that produces a practical checklist — never a fake fine prediction."
      }
    ]
  },

  /* ---------------------------------------------------------------
     4. UNDERSTAND THE ACT — clickable infographic topics
     Each topic: id, icon, title, plain (intro), points[], status,
     nuance (optional callout), refs[{label, source}] and optional
     diagram key rendered by app.js.
     --------------------------------------------------------------- */
  actTopics: [
    {
      id: "scope",
      icon: "compass",
      title: "Who the Act covers",
      plain: "The DPDP Act, 2023 governs digital personal data — data about identifiable people, in digital form.",
      points: [
        "It applies to personal data collected online, and to offline personal data later digitised, processed in India.",
        "It also applies to processing outside India if it offers goods or services to, or profiles, people in India.",
        "It does not apply to personal data processed by an individual for purely personal or domestic purposes, or to offline data that is never digitised.",
        "The Act can be restricted or exempted for certain purposes, such as national security and judicial functions, in the manner the Act provides."
      ],
      status: "may2027",
      refs: [{ label: "DPDP Act, s. 3 and s. 17", source: "act" }],
      diagram: "scope"
    },
    {
      id: "roles",
      icon: "users",
      title: "Data Principals and Data Fiduciaries",
      plain: "Two words you will meet everywhere: the person the data is about, and the entity that decides how it is used.",
      points: [
        "Data Principal — the individual the personal data is about: your customer, employee, patient or student.",
        "Data Fiduciary — the person, company or body that alone or with others decides the purpose and means of processing that data. Businesses usually act as Data Fiduciaries.",
        "Data Processor — processes data on the fiduciary's instructions (a payroll bureau, a cloud vendor). The fiduciary remains accountable for its processor's acts.",
        "Consent Manager — a registered intermediary through which individuals can give, review, manage and withdraw consent across services."
      ],
      status: "may2027",
      refs: [{ label: "DPDP Act, s. 2 (definitions)", source: "act" }],
      diagram: "roles"
    },
    {
      id: "grounds",
      icon: "scale",
      title: "Consent and certain legitimate uses",
      plain: "You may process personal data only on consent — or for one of the certain legitimate uses the Act lists.",
      points: [
        "Valid consent must be free, specific, informed, unconditional and unambiguous, given by a clear affirmative action.",
        "Certain legitimate uses include specified medical emergencies and public-health threats, disaster management, compliance with law and court orders, and specified employment and employer-safeguarding purposes.",
        "Withdrawal of consent must be as easy as giving it, and the fiduciary must stop the processing that relied on it (unless a legitimate use or legal duty applies).",
        "The burden of proving consent lies on the Data Fiduciary."
      ],
      nuance: "Employee data is not automatically consent-free: only the specified employment-related purposes fall under legitimate uses. Other uses still need consent or another lawful ground.",
      status: "may2027",
      refs: [{ label: "DPDP Act, ss. 4–7 (grounds, consent, legitimate uses)", source: "act" }]
    },
    {
      id: "notices",
      icon: "file-text",
      title: "Itemised notices",
      plain: "Before or when you collect data, you must give an itemised description of it — in plain language.",
      points: [
        "Describe the personal data sought and the specific purposes, item by item, in a form the person can understand.",
        "Give the notice in English or any language listed in the Eighth Schedule to the Constitution, and offer those options where feasible.",
        "The DPDP Rules, 2025 add the detailed content and delivery requirements for notices and the accompanying communication link.",
        "Notices become enforceable duties when the main obligations commence on 13 May 2027 — the time to rewrite them is now."
      ],
      status: "may2027",
      refs: [
        { label: "DPDP Act, ss. 4–5", source: "act" },
        { label: "DPDP Rules, 2025 (notices)", source: "rules" }
      ]
    },
    {
      id: "rights",
      icon: "user-check",
      title: "Rights of Data Principals",
      plain: "People get meaningful rights over their data — and you need workflows, not good intentions, to honour them.",
      points: [
        "Access: a summary of the personal data held, what is being done with it, and the identities of other fiduciaries and processors it has been shared with.",
        "Correction, completion, updating and erasure of data, subject to the Act's conditions.",
        "Grievance redressal: you must publish easy ways to complain and respond meaningfully — the Rules contemplate responses within a reasonable period, capped at ninety days — before the person escalates to the Board.",
        "Nomination: individuals can nominate someone to exercise their rights if they die or are incapacitated.",
        "The Rules add deemed erasure duties for large e-commerce, online-gaming and social-media platforms whose users' accounts stay inactive for long periods."
      ],
      status: "may2027",
      refs: [
        { label: "DPDP Act, ss. 11–14", source: "act" },
        { label: "DPDP Rules, 2025 (rights and grievance timelines)", source: "rules" }
      ]
    },
    {
      id: "dp-duties",
      icon: "check",
      title: "Duties of Data Principals",
      plain: "Rights come with responsibilities — the Act also sets duties for the people whose data it protects.",
      points: [
        "Furnish only authentic information when complying with a law that requires information.",
        "Not impersonate another person while providing certain records, and not suppress material information.",
        "Not file frivolous or false grievances or complaints — the Schedule caps the penalty for this at ₹10,000.",
        "These duties target abuse of process; the Board decides any consequence after an inquiry."
      ],
      status: "may2027",
      refs: [{ label: "DPDP Act, s. 16 and the Schedule", source: "act" }]
    },
    {
      id: "security",
      icon: "shield",
      title: "Security safeguards",
      plain: "You must protect personal data in your possession or control with reasonable security safeguards.",
      points: [
        "The Rules spell out a baseline: encryption, masking or virtual tokens; strict access control; logging and monitoring of access (logs kept at least a year); and backups.",
        "Contracts with processors must flow the same obligations down, including audit and information rights for sub-processors.",
        "'Reasonable' is judged in your context — data sensitivity, scale, architecture and risk all matter.",
        "Failure to take reasonable security safeguards attracts the Act's highest penalty category: up to ₹250 crore."
      ],
      status: "may2027",
      refs: [
        { label: "DPDP Act, s. 8", source: "act" },
        { label: "DPDP Rules, 2025 (security safeguards)", source: "rules" }
      ],
      diagram: "security"
    },
    {
      id: "breach",
      icon: "alert",
      title: "Breach notification",
      plain: "A personal data breach is not just an IT incident — the Act makes telling people a legal duty.",
      points: [
        "Notify the affected Data Principals without delay, covering the nature of the breach, likely consequences, safeguards taken, and a contact point.",
        "Notify the Data Protection Board of India without delay with an initial description, and follow up with detailed information within 72 hours (as the Rules provide).",
        "A breach by itself is not proof your safeguards were inadequate — the Board examines the facts. But silence compounds exposure.",
        "Failure to notify is its own violation category, with a statutory maximum of ₹200 crore."
      ],
      status: "may2027",
      refs: [
        { label: "DPDP Act, s. 8", source: "act" },
        { label: "DPDP Rules, 2025 (breach intimation)", source: "rules" }
      ]
    },
    {
      id: "retention",
      icon: "clock",
      title: "Retention and erasure",
      plain: "Keep personal data only as long as the purpose is served — then erase it, unless a law requires you to keep it.",
      points: [
        "Erase data once consent is withdrawn or the specified purpose is no longer served, unless retention is required by law.",
        "The Rules set a three-year erasure period for eligible data held by large e-commerce, online-gaming and social-media platforms, with a minimum one-year retention of data and logs needed to demonstrate lawful processing.",
        "Sector laws continue to apply: if RBI or SEBI norms require you to keep KYC records for a period, that legal duty prevails over erasure.",
        "Publish the contact details of your Data Protection Officer or authorised person so people know whom to approach."
      ],
      status: "may2027",
      refs: [
        { label: "DPDP Act, s. 8", source: "act" },
        { label: "DPDP Rules, 2025 (erasure and DPO contact)", source: "rules" }
      ]
    },
    {
      id: "children",
      icon: "id-card",
      title: "Children's data",
      plain: "Anyone under 18 is a child under the Act — and children's data gets stricter treatment.",
      points: [
        "Processing a child's data generally requires verifiable consent of the parent or guardian, established through prescribed methods (identity verification with liveness or face-match checks, or Aadhaar-based tokens given voluntarily).",
        "The Act prohibits tracking, behavioural monitoring and targeted advertising directed at children, and processing likely to be detrimental to a child's well-being.",
        "The Rules extend guardian consent to persons with disability who have a lawful guardian.",
        "The Fourth Schedule to the Rules carves out practical exemptions — e.g. healthcare by clinics, educational institutions' tracking for educational purposes, transport and crèche safety, and services limited to email accounts or parental location tracking."
      ],
      nuance: "Child-data scenarios are not identical: what counts as verifiable consent, and which exemption applies, depends on who you are and why you process. Check the Fourth Schedule before assuming.",
      status: "may2027",
      refs: [
        { label: "DPDP Act, s. 9", source: "act" },
        { label: "DPDP Rules, 2025 (children and guardians, Fourth Schedule)", source: "rules" }
      ]
    },
    {
      id: "sdf",
      icon: "building",
      title: "Significant Data Fiduciaries",
      plain: "The Central Government will notify certain classes of Data Fiduciaries as 'Significant' — with extra duties.",
      points: [
        "Designation is by government notification, based on factors such as the volume and sensitivity of data processed and the risk to Data Principals' rights.",
        "SDF duties include annual Data Protection Impact Assessments and audits, an independent data auditor, a Data Protection Officer resident in India, and algorithmic due diligence.",
        "The Government may also restrict cross-border transfers by notified SDFs.",
        "SDF obligations have their own penalty category: up to ₹150 crore for breach."
      ],
      nuance: "Do not assume every large SaaS provider is an SDF. Status comes by notification — watch for the Government's list rather than self-declaring.",
      status: "may2027",
      refs: [
        { label: "DPDP Act, s. 10", source: "act" },
        { label: "DPDP Rules, 2025 (SDF obligations)", source: "rules" }
      ]
    },
    {
      id: "transfers",
      icon: "network",
      title: "Cross-border transfers",
      plain: "Transfers outside India are allowed — except to countries on a restriction list the Government may notify.",
      points: [
        "The default is permissive: the Act permits transfers, and the Rules provide for a notified negative-list approach rather than case-by-case approval.",
        "Significant Data Fiduciaries can face additional destination restrictions.",
        "Even where a transfer is permitted, your security-safeguard, notice and processor-contract duties travel with the data.",
        "Watch this space: the restriction list is notified over time and changes the map for multi-region architectures."
      ],
      status: "may2027",
      refs: [
        { label: "DPDP Act, s. 16", source: "act" },
        { label: "DPDP Rules, 2025 (transfers)", source: "rules" }
      ]
    }
  ],

  /* ---------------------------------------------------------------
     5. TIMELINE — phased commencement of the DPDP Act
     status: "past" (already happened), "live" (in force),
     "scheduled" (future commencement). Update after each notification
     and refresh lastVerified above.
     --------------------------------------------------------------- */
  timeline: [
    {
      iso: "2023-08-18",
      date: "18 August 2023",
      title: "The DPDP Act, 2023 becomes law",
      text: "Parliament passes the Digital Personal Data Protection Bill; the Act receives Presidential assent as Act No. 22 of 2023. It consolidates India's framework for digital personal data.",
      status: "past",
      refs: [{ label: "DPDP Act, 2023 (India Code)", source: "act" }]
    },
    {
      iso: "2025-01-03",
      date: "3 January 2025",
      title: "Draft DPDP Rules released for consultation",
      text: "MeitY publishes the draft Digital Personal Data Protection Rules for public consultation — the first detailed view of how the Act would operate in practice.",
      status: "past",
      refs: [{ label: "MeitY (Rules and consultations)", source: "meity" }]
    },
    {
      iso: "2025-11-13",
      date: "13 November 2025",
      title: "Phase 1 — the machinery comes into force",
      text: "The DPDP Rules, 2025 are notified (G.S.R. 846(E)), and the commencement notification (G.S.R. 843(E)) brings the Act's institutional provisions into force: the Data Protection Board of India, appeals and related machinery (ss. 1(2), 2, 18–26, 35, 38–43 and 44(1) & (3) of the Act; Rules 1, 2 and 17–21).",
      status: "live",
      refs: [
        { label: "Commencement notification, G.S.R. 843(E)", source: "commencement" },
        { label: "DPDP Rules, 2025 — G.S.R. 846(E)", source: "rules" }
      ]
    },
    {
      iso: "2026-11-13",
      date: "13 November 2026",
      title: "Phase 2 — the Consent Manager framework",
      text: "One year after notification, the Consent Manager provisions commence (s. 6(9) of the Act, the related inquiry basis in s. 27(1)(d), and Rule 4 on Consent Manager registration). The consent infrastructure is scheduled to be ready ahead of the main duties.",
      status: "scheduled",
      refs: [
        { label: "Commencement notification, G.S.R. 843(E)", source: "commencement" },
        { label: "DPDP Rules, 2025 (Consent Managers)", source: "rules" }
      ]
    },
    {
      iso: "2027-05-13",
      date: "13 May 2027",
      title: "Phase 3 — main duties and the penalty regime",
      text: "Eighteen months after notification, the substantive obligations commence: grounds, consent and notices, fiduciary obligations, security safeguards, breach reporting, rights and grievance redressal, children's data, SDF duties (ss. 3–17, 27–34, 36–37 and 44(2); Rules 3, 5–16, 22–23). Penalties under the Schedule become enforceable. MeitY has publicly confirmed this date.",
      status: "scheduled",
      refs: [
        { label: "Commencement notification, G.S.R. 843(E)", source: "commencement" },
        { label: "MeitY statement on implementation", source: "meity" }
      ]
    }
  ],

  timelineToday: {
    label: "You are here",
    note: "As of 25 September 2026 — the Board and Rules machinery is in force; the main duties and penalty regime are scheduled for 13 May 2027."
  },

  /* ---------------------------------------------------------------
     6. SERVICES — DRAFT cards. CYBER CIBIL must confirm its
     actual offerings, then remove the draft banner.
     --------------------------------------------------------------- */
  servicesDraftNote: "Draft catalogue: these cards are editable drafts of what CYBER CIBIL could offer. Confirm, edit or remove each card in assets/js/content.js before publishing.",

  services: [
    {
      icon: "search",
      title: "DPDP readiness assessment",
      problem: "You do not know how far your current practices are from what the Act and Rules demand — or what to fix first.",
      deliverables: [
        "Structured gap review against the Act and DPDP Rules, 2025",
        "Prioritised action plan with owners and deadlines",
        "Executive summary for leadership and board"
      ]
    },
    {
      icon: "map",
      title: "Data mapping",
      problem: "Personal data sits scattered across apps, spreadsheets, exports and vendors — nobody has one picture of it.",
      deliverables: [
        "Personal-data inventory across systems and teams",
        "Flow maps showing where data goes, including processors",
        "Retention register with legal-hold and sector-law overlays"
      ]
    },
    {
      icon: "file-text",
      title: "Notices and consent design",
      problem: "Collection notices are dense walls of text, and consent flows do not meet the Act's standard.",
      deliverables: [
        "Rewritten itemised notices in plain language",
        "Consent and withdrawal journey design for every touchpoint",
        "Language and delivery options aligned to the Rules"
      ]
    },
    {
      icon: "user-check",
      title: "Rights-request workflows",
      problem: "Access, correction and erasure requests arrive with no owner, no process and no audit trail.",
      deliverables: [
        "Intake, verification and response workflow with SLAs",
        "Response templates and escalation paths",
        "Evidence log that stands up to Board questions"
      ]
    },
    {
      icon: "shield",
      title: "Security and breach readiness",
      problem: "Safeguards are undocumented and inconsistent, and a breach would be handled on pure adrenaline.",
      deliverables: [
        "Security baseline mapped to the Rules (encryption, access, logging, backups)",
        "Breach runbook including people-notification and Board intimation within timelines",
        "Tabletop exercise with your response team"
      ]
    },
    {
      icon: "network",
      title: "Processor and vendor governance",
      problem: "Vendors process personal data on your behalf with contracts that say nothing about DPDP.",
      deliverables: [
        "Processor register with risk tiers",
        "Contract clause library for DPDP obligations, audits and sub-processors",
        "Due-diligence checklist for onboarding new vendors"
      ]
    },
    {
      icon: "id-card",
      title: "Children's data controls",
      problem: "If any of your users are under 18 — or have guardians — the strictest rules in the Act apply to you.",
      deliverables: [
        "Child-data exposure review across products and analytics",
        "Verifiable parental or guardian consent flow design",
        "Switch-off plan for tracking and targeted ads directed at children"
      ]
    },
    {
      icon: "users",
      title: "Staff training",
      problem: "Most incidents start with people, not code — and teams have never been briefed on the Act.",
      deliverables: [
        "Role-based training modules (sales, HR, support, engineering)",
        "Induction pack and refresh cadence",
        "Scenario drills drawn from your sector's failure patterns"
      ]
    },
    {
      icon: "refresh",
      title: "Ongoing support",
      problem: "The Rules ecosystem keeps moving through 2027 — SDF notifications, transfer lists, Consent Managers.",
      deliverables: [
        "Regulatory watch with plain-language alerts",
        "Quarterly readiness reviews and evidence refresh",
        "Board-ready reporting packs"
      ]
    }
  ],

  /* ---------------------------------------------------------------
     7. SECTOR EXPLORER — all scenarios are ILLUSTRATIVE, not
     sector-specific law or predicted fines. Penalty categories are
     statutory maximums by violation type.
     --------------------------------------------------------------- */
  sectorsIntro: "Every tab below shows typical personal-data flows, an illustrative failure scenario, the potentially relevant DPDP duty, its statutory maximum penalty category, and a matching draft service add-on. Examples are illustrative — the Act does not set sector-specific duties or penalty rates.",

  sectors: [
    {
      id: "bfsi",
      icon: "landmark",
      label: "BFSI",
      headline: "Banking, financial services and insurance",
      flows: ["KYC and onboarding documents", "Transaction and payment data", "Credit assessments and scores", "Claims and policy records", "Service-call recordings"],
      scenario: "A digital lending platform keeps the KYC records of rejected applicants for years after the decision — long after the purpose ended — and cannot answer erasure requests because nobody owns the data map.",
      duty: "Keep personal data only while the purpose is served, then erase it unless a law requires retention (s. 8). Note the interplay: RBI's KYC retention norms still apply — DPDP does not erase sector-law duties.",
      penaltyCategory: "other",
      addOn: {
        title: "KYC data mapping",
        text: "Map where KYC and e-KYC data lives across origination, lending and collections; align DPDP retention with RBI norms; flow obligations into bureau and processor contracts."
      },
      examples: {
        security: "A digital lender stores KYC documents in a cloud bucket that anyone with the link can open.",
        notify: "A payments app learns of unauthorised access to card data but delays telling the Board and affected customers.",
        other: "Rejected applicants' KYC records are kept for years after the decision, with no erasure path once the purpose has ended."
      }
    },
    {
      id: "healthcare",
      icon: "heart",
      label: "Healthcare",
      headline: "Hospitals, clinics, diagnostics and telehealth",
      flows: ["Outpatient and EMR records", "Diagnostics and prescriptions", "Insurance and claims data", "Appointment and billing details", "Teleconsultation logs"],
      scenario: "A diagnostic chain's patient-report portal exposes records to the open internet because default passwords and shared logins were never changed — and the clinic's team has no breach runbook.",
      duty: "Protect personal data with reasonable security safeguards — encryption, masking, access control, logging and backups — and be ready to notify affected people and the Board when a breach occurs (s. 8; Rules on safeguards and breach intimation).",
      penaltyCategory: "security",
      addOn: {
        title: "Patient-record lifecycle review",
        text: "Trace patient records from registration to disposal across HIS, LIS and cloud backups; fix access control gaps; design a breach-notification path that reaches patients and the Board on time."
      },
      examples: {
        security: "A diagnostic centre's portal exposes patient reports because default passwords and shared logins were never changed.",
        notify: "A hospital's records system is hit by ransomware; affected patients hear about it from the news, not the hospital.",
        children: "A paediatric clinic keeps ad-targeting pixels on a portal used by parents and teens.",
        other: "A clinic sends promotional messages to patients who never consented to marketing."
      }
    },
    {
      id: "ecommerce",
      icon: "cart",
      label: "E-commerce",
      headline: "Marketplaces, D2C brands and retail apps",
      flows: ["Accounts and profiles", "Orders and delivery addresses", "Payment tokens and refunds", "Browsing and marketing preferences", "Support conversations"],
      scenario: "A shopper withdraws marketing consent in the app, but the CRM keeps sending offers because withdrawal never propagated to the marketing stack — and their profile is never erased after the purpose ends.",
      duty: "Honour consent withdrawal as easily as consent is given, erase data once the purpose is served, and keep large platforms' deemed-erasure duties in view (ss. 4–8; Rules on consent, erasure and retention).",
      penaltyCategory: "other",
      addOn: {
        title: "Consent and retention review",
        text: "Audit every consent touchpoint and withdrawal path across app, CRM and ad platforms; set retention periods and erasure triggers per data category, including the Rules' timelines for large platforms."
      },
      examples: {
        notify: "A marketplace's delivery-address database leaks; the company investigates quietly and never notifies affected shoppers.",
        other: "A shopper withdraws marketing consent, but the CRM keeps sending offers because withdrawal never reached the marketing stack.",
        children: "A shopping app profiles users as young as 13 for targeted ads without verifiable parental consent."
      }
    },
    {
      id: "education",
      icon: "cap",
      label: "Education / EdTech",
      headline: "Schools, institutes, coaching and learning apps",
      flows: ["Enrolment and guardian details", "Attendance and performance records", "Fees and payments", "Online-class behaviour data", "Counselling notes"],
      scenario: "An ed-tech app tracks students' study behaviour to serve targeted advertisements, without verifiable parental consent — even though every user is under 18.",
      duty: "Children's data demands verifiable parental or guardian consent, and the Act prohibits tracking, behavioural monitoring and targeted advertising directed at children (s. 9; Rules 10–12 and the Fourth Schedule exemptions).",
      penaltyCategory: "children",
      addOn: {
        title: "Children's data controls",
        text: "Identify under-18 data across products and analytics; design verifiable parental-consent flows; switch off tracking and targeted ads directed at children; document any Fourth Schedule exemption you rely on."
      },
      examples: {
        children: "An ed-tech app tracks students' study behaviour to serve targeted advertisements, without verifiable parental consent.",
        security: "A school's examination portal exposes students' marks and identity documents to the open internet.",
        notify: "An institute's admission database is breached; parents and students are never informed."
      }
    },
    {
      id: "saas",
      icon: "cloud",
      label: "SaaS",
      headline: "Software platforms and cloud services",
      flows: ["Tenant user accounts", "Usage telemetry and logs", "Billing contacts", "Support tickets", "Customer content hosted for tenants"],
      scenario: "A SaaS provider discovers unauthorised access to a tenant's user database but stays silent — the tenant's own customers are never informed, and the provider's role in the chain was never documented.",
      duty: "Be clear about your role — fiduciary for your own data, processor for tenant-controlled data — keep security safeguards current, and meet breach-notification duties when they apply to you (s. 8; Rules on safeguards, breach intimation and processor contracts).",
      penaltyCategory: "notify",
      addOn: {
        title: "Processor-role and contract review",
        text: "Map fiduciary vs processor roles per data flow; align customer and sub-processor contracts with the Rules; build a breach-notification path that works across the tenant chain."
      },
      nuance: "Being a SaaS company does not make you a Significant Data Fiduciary — SDF status arrives only by government notification.",
      examples: {
        security: "A vendor's multi-tenant database lacks encryption and access logs; a former employee's credentials still work months later.",
        notify: "A SaaS provider discovers unauthorised access to a tenant's user data but stays silent; the tenant's customers are never told.",
        sdf: "Applies only if notified as an SDF: a very large platform skips its annual DPIA and audit and has no India-resident DPO."
      }
    },
    {
      id: "hr",
      icon: "briefcase",
      label: "HR",
      headline: "People teams and workforce data",
      flows: ["Job applicants and CVs", "Payroll and statutory benefits", "Performance and appraisal data", "Background verification", "Exit and alumni records"],
      scenario: "A company keeps ex-employees' salary and background-verification records indefinitely 'just in case', with no retention rule or erasure path — and assumes every employee-data use is covered by 'employment purposes'.",
      duty: "Certain employment-related purposes qualify as legitimate uses, but not every workforce use does — the rest need consent or another ground, plus safeguards, retention limits and grievance channels (ss. 4–8).",
      penaltyCategory: "other",
      addOn: {
        title: "Workforce-data governance",
        text: "Classify every workforce use — legitimate use vs consent — across recruitment, payroll and monitoring; set retention and erasure rules; fix background-vendor contracts and access control."
      },
      examples: {
        security: "Payroll data sits in an open shared drive that every employee, intern and vendor can browse.",
        notify: "A background-verification vendor leaks candidate data; the employer waits for the vendor to 'handle it' and never notifies anyone.",
        other: "Ex-employees' salary and background-check records are kept indefinitely with no retention rule or erasure path."
      }
    }
  ],

  /* ---------------------------------------------------------------
     8. PENALTIES — statutory maximums by violation category.
     DO NOT present these as sector rates, predictions or automatic
     fines; the Board determines penalties after an inquiry.
     --------------------------------------------------------------- */
  penaltiesDisclaimer: "The DPDP Act does not set separate penalty rates for each sector. These are statutory maximums for violation categories, not predicted or automatic fines.",

  penalties: [
    {
      id: "security",
      icon: "shield",
      amountCr: 250,
      title: "Failure to take reasonable security safeguards to prevent a personal data breach",
      text: "Covers not protecting personal data in your possession or control with reasonable safeguards — judged in your context, not against a checklist of buzzwords."
    },
    {
      id: "notify",
      icon: "bell",
      amountCr: 200,
      title: "Failure to notify the Board or affected people of a personal data breach",
      text: "Covers not telling the Data Protection Board of India or the affected Data Principals about a personal data breach as the Act requires."
    },
    {
      id: "children",
      icon: "id-card",
      amountCr: 200,
      title: "Breach of children's data obligations",
      text: "Covers failures of the duties around processing personal data of children — including verifiable parental consent and the ban on tracking and targeted advertising directed at children."
    },
    {
      id: "sdf",
      icon: "building",
      amountCr: 150,
      title: "Breach of Significant Data Fiduciary obligations",
      text: "Applies to fiduciaries the Government has notified as Significant — covering duties like the India-resident DPO, annual DPIAs and audits. If you have not been notified, this category does not apply to you."
    },
    {
      id: "other",
      icon: "doc",
      amountCr: 50,
      title: "Any other breach of the Act or the Rules",
      text: "The catch-all for remaining obligations — notices, consent records, rights workflows, retention and the rest of the Act and DPDP Rules, 2025."
    }
  ],

  penaltiesNotes: [
    "The Data Protection Board of India determines any penalty after an inquiry — a listed maximum is not an automatic or predicted fine.",
    "Do not add category maximums together for a 'worst case' number. The Board decides on the facts of the case before it.",
    "A personal data breach by itself is not proof that security safeguards were inadequate — that is a separate question the Board examines.",
    "Sector examples on this site are illustrative. Your exposure depends on your facts, not your industry label.",
    "The penalty provisions are scheduled to commence on 13 May 2027, with the Act's main duties."
  ],

  scheduleExtra: [
    { title: "Duties of Data Principals", amount: "Up to ₹10,000", text: "Filing frivolous or false grievances or complaints is capped at ₹10,000 — the Act's only penalty aimed at individuals, and it targets abuse of process, not mistakes." },
    { title: "Voluntary undertakings", amount: "Settled by the Board", text: "The Schedule also contemplates voluntary undertakings — commitments the Board may accept from a fiduciary to take or refrain from actions, instead of proceeding to a penalty." }
  ],

  /* ---------------------------------------------------------------
     9. READINESS JOURNEY
     --------------------------------------------------------------- */
  journey: [
    {
      icon: "search",
      title: "Discover data",
      goal: "Build one honest picture of the personal data you hold and where it flows.",
      activities: [
        "Inventory systems, spreadsheets, exports and vendors holding personal data",
        "Record data categories, purposes, volumes and owners",
        "Map flows to processors and cross-border destinations"
      ],
      outputs: "Data map and processing register"
    },
    {
      icon: "scale",
      title: "Identify gaps",
      goal: "Compare the map against what the Act and Rules actually demand.",
      activities: [
        "Test consent, notice and withdrawal against the Act's standard",
        "Check safeguards, logging and backups against the Rules' baseline",
        "Flag child-data, SDF and transfer exposure; note sector-law overlaps"
      ],
      outputs: "Prioritised gap register"
    },
    {
      icon: "workflow",
      title: "Design controls",
      goal: "Decide how each gap closes — in policy, product and contracts.",
      activities: [
        "Rewrite notices; design consent and withdrawal journeys",
        "Set retention periods and erasure triggers per category",
        "Draft processor clauses and choose safeguard improvements"
      ],
      outputs: "Control set, notices and policies"
    },
    {
      icon: "check",
      title: "Implement workflows",
      goal: "Make the controls live — with owners, timelines and evidence.",
      activities: [
        "Stand up rights-request intake, verification and response",
        "Run breach-response drills, including Board intimation timelines",
        "Train the teams who touch personal data daily"
      ],
      outputs: "Live workflows, trained teams"
    },
    {
      icon: "refresh",
      title: "Monitor and improve",
      goal: "Keep readiness current as notifications, SDF lists and Rules evolve.",
      activities: [
        "Set an audit and DPIA cadence (mandatory if notified as an SDF)",
        "Track regulatory changes through 2027 and beyond",
        "Refresh the data map as systems and vendors change"
      ],
      outputs: "Review rhythm and evidence trail"
    }
  ],

  assessmentIntro: "40 checks across DPDP, cybersecurity, IT operations and Cyber Insurance. Allow 10–15 minutes. Get a visual gap analysis and an actionable checklist. Answers stay on this page; no sign-up needed.",

  assessment: [
    {
      q: "Do you have a current inventory of the personal data you collect, where it is stored, and how long you keep it?",
      step: 0,
      action: "Build a data inventory: catalogue every system, database, spreadsheet and vendor that holds personal data, with owner and purpose for each."
    },
    {
      q: "Can you produce an itemised notice describing the personal data and purposes for each collection point (forms, apps, counters)?",
      step: 2,
      action: "List every collection point and draft an itemised description of the data and purposes for each, in plain language."
    },
    {
      q: "If someone withdraws consent, does that withdrawal reach every system that relied on it (CRM, messaging, analytics)?",
      step: 3,
      action: "Design withdrawal to be as easy as giving consent, and trace every downstream system it must reach."
    },
    {
      q: "Do you have a documented workflow for access, correction and erasure requests, with owners and response timelines?",
      step: 3,
      action: "Stand up an intake-and-response workflow for rights requests, with named owners, templates and evidence logging."
    },
    {
      q: "Are your security safeguards documented and reviewed in the last year (encryption or masking, access control, logging, backups)?",
      step: 2,
      action: "Document a security baseline: encryption or masking, strict access control, logging and monitoring, and backups — mapped to the Rules' expectations."
    },
    {
      q: "Do you have a breach runbook that covers notifying affected people without delay and the Board with details within 72 hours?",
      step: 3,
      action: "Write a breach runbook: contain, assess, notify people without delay, and prepare the Board's detailed intimation within 72 hours."
    },
    {
      q: "Do your vendor and processor contracts flow down DPDP obligations, audits and sub-processor controls?",
      step: 2,
      action: "Map processors and vendors, then retrofit contracts with DPDP obligations, audit rights and sub-processor clauses."
    },
    {
      q: "Where you process children's data or data requiring guardian consent, are appropriate verifiable-consent controls in place? Choose N/A if outside your scope.",
      step: 2,
      action: "Check for under-18 data across products and analytics; if present, design verifiable parental or guardian consent and disable tracking and targeted ads directed at children."
    },
    {
      q: "Are retention periods and erasure paths defined for each data category, respecting sector-law retention duties?",
      step: 3,
      action: "Define retention periods and erasure triggers per data category, overlaying any sector-law retention duties that prevail."
    },
    {
      q: "Is there a named accountable owner for DPDP readiness, and have data-handling staff been trained?",
      step: 4,
      action: "Name an accountable owner (whose contact you can publish), and run role-based training for everyone who handles personal data."
    }
  ],

  /* ---------------------------------------------------------------
     10. FAQ
     --------------------------------------------------------------- */
  faqs: [
    {
      q: "What is the DPDP Act, 2023?",
      a: "India's Digital Personal Data Protection Act, 2023 (Act No. 22 of 2023) sets out when and how digital personal data may be processed, the rights of the people it describes (Data Principals), the duties of the entities that control it (Data Fiduciaries), and the penalty powers of the Data Protection Board of India."
    },
    {
      q: "Who does the Act apply to?",
      a: "It applies to digital personal data processed in India — whether collected online or digitised later — and to processing outside India that offers goods or services to, or profiles, people in India. It does not cover purely personal or domestic processing, or offline data that is never digitised."
    },
    {
      q: "When do the obligations actually start?",
      a: "In phases. The Act's institutional machinery (including the Data Protection Board) came into force on 13 November 2025 along with the DPDP Rules, 2025. Consent Manager provisions are scheduled for 13 November 2026. The main duties on businesses — consent, notices, security, breach reporting, rights, children's data — and the penalty regime commence on 13 May 2027."
    },
    {
      q: "What is a Data Fiduciary — are we one?",
      a: "A Data Fiduciary is any person, company or body that decides the purpose and means of processing personal data. If you decide why and how customer, employee or patient data is used, you are very likely a Data Fiduciary — even if a vendor's servers do the actual processing."
    },
    {
      q: "Do we need consent for every employee record?",
      a: "No — and not automatically no, either. The Act lists certain legitimate uses, including specified employment and employer-safeguarding purposes. Uses that fall within those descriptions can proceed without consent; uses outside them still need consent or another lawful ground, alongside notice and security safeguards. Classify each workforce use case rather than assuming a blanket answer."
    },
    {
      q: "Is our SaaS company a Significant Data Fiduciary?",
      a: "Only if the Central Government notifies you (or a class you belong to) as one. Size or business model alone does not confer SDF status. If notified, extra duties apply: an India-resident Data Protection Officer, annual DPIAs and audits, an independent data auditor and algorithmic due diligence."
    },
    {
      q: "Are penalties different for banking versus health versus retail?",
      a: "No. The Act sets statutory maximums for categories of violation — security-safeguard failures, breach-notification failures, children's-data breaches, SDF breaches, and a catch-all — not for industries. The Data Protection Board determines any penalty after an inquiry, on the facts of the case."
    },
    {
      q: "What must we do when a personal data breach happens?",
      a: "Notify the affected Data Principals without delay — covering the nature of the breach, likely consequences, safeguards taken and a contact point — and intimate the Data Protection Board of India without delay, with detailed information within 72 hours as the Rules provide. These duties are part of the main regime scheduled to commence on 13 May 2027; building the runbook before then is the point."
    },
    {
      q: "What are Consent Managers?",
      a: "Registered intermediaries that let individuals give, review, manage and withdraw consent across services through one interoperable platform. The framework (including registration under Rule 4) is scheduled to become operable from 13 November 2026, ahead of the main duties."
    },
    {
      q: "How is the DPDP Act different from the GDPR?",
      a: "Both are rights-based data protection laws, but they differ in structure: the DPDP Act works on a consent-plus-legitimate-uses model, uses a penalty Schedule with fixed maximums rather than turnover-linked fines, takes a notified-restriction approach to cross-border transfers, and treats all under-18s as children. If you are GDPR-compliant, you have a head start — not a finish line."
    },
    {
      q: "What should we prioritise before May 2027?",
      a: "Start with visibility: a data inventory and map. Then close ground-level gaps — notices and consent journeys, security baseline, breach runbook, rights workflows, vendor contracts — and train your teams. The self-assessment on our Readiness page turns this into a checklist you can act on this week."
    },
    {
      q: "Is the content on this site legal advice?",
      a: "No. It is plain-language information about the DPDP Act and Rules, verified against official sources and dated. For advice on your specific situation, consult a qualified lawyer — or book a readiness call and we will help you frame the right questions."
    }
  ],

  /* ---------------------------------------------------------------
     11. PRIVACY NOTICE — DRAFT template for this website itself.
     Replace bracketed parts and have it reviewed before publishing.
     --------------------------------------------------------------- */
  privacyNotice: {
    updated: "25 September 2026",
    paragraphs: [
      "This draft privacy notice explains how CYBER CIBIL ('we', 'us') handles personal data when you use this website. Replace the bracketed details and have the notice reviewed before publishing.",
      "What we collect: when you submit the inquiry form, we collect the details you provide — name, work email, company and message. We also receive standard technical logs (such as IP address and browser type) if analytics are enabled.",
      "Why we collect it: to respond to your inquiry and, where you agree, to follow up about DPDP readiness services. We do not sell your data.",
      "Where it goes: submissions are processed by our secure email and client management system. We do not share your data with other third parties beyond what is needed to operate the site.",
      "How long we keep it: only as long as needed to handle your inquiry, unless a law requires longer retention.",
      "Your rights: under the DPDP Act you can ask to access, correct or erase your data, and raise a grievance. Write to info@icn3.com and we will respond within a reasonable period, not exceeding ninety days.",
      "Changes: we will update this notice when our practices change, with the revised date shown above."
    ]
  },

  /* ---------------------------------------------------------------
     12. FOOTER
     --------------------------------------------------------------- */
  footerDisclaimer: "This website provides general information about the Digital Personal Data Protection Act, 2023 and the DPDP Rules, 2025 in plain language. It is not legal advice, and no attorney-client relationship is created by using it. CYBER CIBIL is a private firm; it is not affiliated with, endorsed by, or acting for the Government of India or the Data Protection Board of India. Sector examples are illustrative. Legal content is verified against the official sources linked above."
};
