/* =====================================================================
   CYBER CIBIL — DPDP website shared app JS
   Rendering + interactions. All editable content lives in content.js.
   ===================================================================== */
(function () {
  "use strict";

  var SITE = window.SITE || {};
  var REDUCED = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---------- tiny helpers ---------- */
  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function icon(name, cls) {
    return '<svg class="ic ' + (cls || "") + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (ICONS[name] || ICONS.doc) + "</svg>";
  }

  /* ---------- inline icon set (original, stroke-based) ---------- */
  var SHIELD = '<path d="M12 3l7.2 2.9v5.3c0 4.6-3 7.7-7.2 9.3-4.2-1.6-7.2-4.7-7.2-9.3V5.9L12 3z"/>';
  var ICONS = {
    shield: SHIELD,
    "shield-check": SHIELD + '<path d="M9 11.6l2.1 2.1 4-4.4"/>',
    lock: '<rect x="5.5" y="10.5" width="13" height="9.5" rx="2"/><path d="M8.5 10.5V8a3.5 3.5 0 017 0v2.5"/>',
    user: '<circle cx="12" cy="7.8" r="3.6"/><path d="M5 20c1.4-3.4 3.9-5 7-5s5.6 1.6 7 5"/>',
    "user-check": '<circle cx="9" cy="8" r="3.4"/><path d="M2.5 20c1.3-3.2 3.7-4.7 6.5-4.7 1.4 0 2.7.4 3.8 1.1"/><path d="M15 9l2.2 2.2L21.5 7"/>',
    users: '<circle cx="9" cy="8" r="3.3"/><path d="M2.8 20c1.2-3 3.5-4.6 6.2-4.6 1.5 0 2.8.4 3.9 1.2"/><path d="M15.5 5.1a3.3 3.3 0 010 5.8M17.6 15.6c1.5.8 2.7 2 3.5 3.7"/>',
    briefcase: '<rect x="3.5" y="8" width="17" height="12" rx="2"/><path d="M9 8V6.5A1.5 1.5 0 0110.5 5h3A1.5 1.5 0 0115 6.5V8M3.5 13h17"/>',
    landmark: '<path d="M3.5 9L12 4l8.5 5"/><path d="M5.5 9.5V17M9.8 9.5V17M14.2 9.5V17M18.5 9.5V17M3.5 20.5h17M3.5 17h17"/>',
    heart: '<path d="M12 20.2S4 15.4 4 10.3C4 7.4 6.2 5.3 8.7 5.3c1.4 0 2.6.7 3.3 1.8.7-1.1 1.9-1.8 3.3-1.8 2.5 0 4.7 2.1 4.7 5 0 5.1-8 9.9-8 9.9z"/>',
    cart: '<circle cx="9.5" cy="20" r="1.4"/><circle cx="17" cy="20" r="1.4"/><path d="M3 4h2.2l2.5 11.4a1 1 0 001 .8h8.6a1 1 0 001-.8L20.5 8H6"/>',
    cap: '<path d="M12 4L2 9l10 5 10-5-10-5z"/><path d="M6.5 11.5V16c0 1.4 2.8 2.8 5.5 2.8s5.5-1.4 5.5-2.8v-4.5M21 9v5"/>',
    cloud: '<path d="M7 18.5a4.3 4.3 0 01-.5-8.6 5.6 5.6 0 0110.9 1.2 3.6 3.6 0 01-.9 7.4H7z"/>',
    scale: '<path d="M12 4v15M8.5 19h7M4 8h16M12 5.5L4 8M12 5.5L20 8"/><path d="M6.5 8l-2.2 4.6a2.6 2.6 0 004.4 0L6.5 8zM17.5 8l-2.2 4.6a2.6 2.6 0 004.4 0L17.5 8z"/>',
    calendar: '<rect x="4" y="5.5" width="16" height="15" rx="2"/><path d="M4 10.5h16M8.5 3.5v4M15.5 3.5v4"/>',
    alert: '<path d="M12 3.5L21 19.5H3L12 3.5z"/><path d="M12 10v4.2M12 17.3v.2"/>',
    search: '<circle cx="11" cy="11" r="6.5"/><path d="M16 16l5 5"/>',
    map: '<circle cx="5" cy="19" r="2"/><circle cx="19" cy="5" r="2"/><path d="M7 18.6h6.5a4 4 0 000-8H10a4 4 0 010-8h7"/>',
    refresh: '<path d="M20 11.5a8 8 0 10-2.2 6.1"/><path d="M20 5.5v6h-6"/>',
    chart: '<path d="M4 20.5h16"/><path d="M7 20.5V14M12 20.5V7.5M17 20.5v-9"/>',
    mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3.5 7.5l8.5 6 8.5-6"/>',
    phone: '<path d="M5.5 4h3.6l1.6 4.6-2.4 1.9a12.8 12.8 0 005.2 5.2l1.9-2.4L20 14.9v3.6a1.9 1.9 0 01-2 1.9A16.4 16.4 0 013.6 6a1.9 1.9 0 011.9-2z"/>',
    pin: '<path d="M12 21s-6.8-5.8-6.8-10.7a6.8 6.8 0 0113.6 0C18.8 15.2 12 21 12 21z"/><circle cx="12" cy="10" r="2.4"/>',
    clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3.3 2"/>',
    book: '<path d="M4.5 19.2A2.3 2.3 0 016.8 17H19.5V3.5H6.8a2.3 2.3 0 00-2.3 2.3v13.4z"/><path d="M4.5 19.2A2.3 2.3 0 006.8 21.5h12.7v-4.5"/>',
    info: '<circle cx="12" cy="12" r="8.5"/><path d="M12 11v5M12 7.6v.2"/>',
    "arrow-right": '<path d="M4.5 12h15M13.5 6l6 6-6 6"/>',
    external: '<path d="M14 4.5h5.5V10M19.5 4.5L11 13"/><path d="M17 13.5v5a1.5 1.5 0 01-1.5 1.5h-10A1.5 1.5 0 014 18.5v-10A1.5 1.5 0 015.5 7h5"/>',
    check: '<path d="M4.5 12.5l5 5L20 6.5"/>',
    "chevron-down": '<path d="M6.5 9.5l5.5 5.5 5.5-5.5"/>',
    download: '<path d="M12 4v11M7.5 11l4.5 4.5 4.5-4.5M4.5 20h15"/>',
    copy: '<rect x="9" y="9" width="11.5" height="11.5" rx="2"/><path d="M5.5 14.5h-1a1 1 0 01-1-1V4a1 1 0 011-1h9.5a1 1 0 011 1v1"/>',
    print: '<path d="M7 8V3.5h10V8"/><path d="M7 17.5H5a2 2 0 01-2-2v-5a2 2 0 012-2h14a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="7" y="14.5" width="10" height="6.5"/>',
    network: '<circle cx="12" cy="5" r="2.3"/><circle cx="5" cy="18.5" r="2.3"/><circle cx="19" cy="18.5" r="2.3"/><path d="M12 7.3v4M12 11.3l-5.7 5.2M12 11.3l5.7 5.2"/>',
    database: '<ellipse cx="12" cy="5.5" rx="7" ry="2.7"/><path d="M5 5.5V18.4c0 1.5 3.1 2.7 7 2.7s7-1.2 7-2.7V5.5"/><path d="M5 12c0 1.5 3.1 2.7 7 2.7s7-1.2 7-2.7"/>',
    server: '<rect x="3" y="4" width="18" height="7" rx="2"/><rect x="3" y="13" width="18" height="7" rx="2"/><path d="M7 7.5v.01M7 16.5v.01"/>',
    eye: '<path d="M2.5 12S6 5.8 12 5.8 21.5 12 21.5 12 18 18.2 12 18.2 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="2.8"/>',
    bell: '<path d="M6.2 9.3a5.8 5.8 0 0111.6 0c0 4.8 1.9 5.9 1.9 5.9H4.3s1.9-1.1 1.9-5.9z"/><path d="M10 18.6a2.1 2.1 0 004 0"/>',
    building: '<rect x="5" y="3.5" width="14" height="17"/><path d="M9 7.5h2M13 7.5h2M9 11h2M13 11h2M9 14.5h2M13 14.5h2M10.8 20.5v-3h2.4v3"/>',
    "id-card": '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="8.3" cy="11" r="1.9"/><path d="M5.5 15.8c.5-1.5 1.6-2.2 2.8-2.2s2.3.7 2.8 2.2M14 9.5h4.2M14 13h4.2"/>',
    workflow: '<circle cx="6" cy="7" r="2.2"/><circle cx="6" cy="17" r="2.2"/><circle cx="18" cy="7" r="2.2"/><path d="M8.2 7h7.6M6 9.2v5.6M8.2 17h7.6c2.1 0 3.4-1.4 3.4-3.6V9.2"/>',
    doc: '<path d="M7 3.5h7l4 4v13H7z"/><path d="M14 3.5v4h4M10 12h5M10 15.5h5"/>',
    "file-text": '<path d="M7 3.5h7l4 4v13H7z"/><path d="M14 3.5v4h4M10 11.5h5M10 15h5"/>',
    compass: '<circle cx="12" cy="12" r="8.5"/><path d="M15.5 8.5l-2 5-5 2 2-5 5-2z"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    spark: '<path d="M12 2.5l2.3 7.2L21.5 12l-7.2 2.3L12 21.5l-2.3-7.2L2.5 12l7.2-2.3L12 2.5z"/>'
  };

  /* ---------- placeholder detection ---------- */
  var PH_RE = /\[[A-Z][A-Z0-9 ,.\-/()&—–-]{2,}\]/g;
  function isPlaceholder(v) { return typeof v === "string" && v.trim().startsWith("[") ; }

  function markPlaceholders(root) {
    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode: function (n) {
        var p = n.parentNode, tag = p && p.nodeName;
        if (tag === "SCRIPT" || tag === "STYLE" || tag === "NOSCRIPT" || tag === "TEXTAREA") return NodeFilter.FILTER_REJECT;
        PH_RE.lastIndex = 0;
        return PH_RE.test(n.nodeValue) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
      }
    });
    var nodes = [], n;
    while ((n = walker.nextNode())) nodes.push(n);
    nodes.forEach(function (node) {
      var frag = document.createDocumentFragment(), s = node.nodeValue, last = 0, m;
      PH_RE.lastIndex = 0;
      while ((m = PH_RE.exec(s))) {
        if (m.index > last) frag.appendChild(document.createTextNode(s.slice(last, m.index)));
        var span = document.createElement("span");
        span.className = "ph"; span.title = "Editable placeholder — replace in assets/js/content.js";
        span.textContent = m[0];
        frag.appendChild(span);
        last = m.index + m[0].length;
      }
      if (last < s.length) frag.appendChild(document.createTextNode(s.slice(last)));
      node.parentNode.replaceChild(frag, node);
    });
  }

  /* ---------- data binding ---------- */
  function get(path) {
    return path.split(".").reduce(function (o, k) { return o == null ? o : o[k]; }, SITE);
  }
  function bind() {
    $$("[data-c]").forEach(function (el) {
      var v = get(el.getAttribute("data-c"));
      if (v != null && v !== "") el.textContent = v;
    });
    $$("[data-c-href]").forEach(function (el) {
      var v = get(el.getAttribute("data-c-href"));
      if (typeof v === "string" && !isPlaceholder(v)) el.setAttribute("href", v);
    });
    $$("[data-mailto]").forEach(function (el) {
      var v = get(el.getAttribute("data-mailto"));
      if (typeof v === "string" && !isPlaceholder(v)) {
        el.setAttribute("href", "mailto:" + v);
        el.textContent = v;
      }
    });
    var brandImg = $('[data-c="company.logoSrc"]');
    if (brandImg) {
      var src = get("company.logoSrc");
      if (typeof src === "string" && src && !isPlaceholder(src)) {
        var holder = $(".brand-mark", brandImg.closest(".brand"));
        if (holder) {
          holder.innerHTML = '<img src="' + esc(src) + '" alt="' + esc(get("company.logoAlt") || "") + '">';
        }
      }
    }
  }

  /* ---------- header ---------- */
  function initHeader() {
    var page = document.body.getAttribute("data-page");
    $$(".site-nav a[data-nav]").forEach(function (a) {
      if (a.getAttribute("data-nav") === page) a.setAttribute("aria-current", "page");
    });
    var burger = $("#burger"), nav = $("#siteNav");
    if (!burger || !nav) return;
    function close() {
      nav.classList.remove("open");
      burger.setAttribute("aria-expanded", "false");
    }
    burger.addEventListener("click", function () {
      var open = nav.classList.toggle("open");
      burger.setAttribute("aria-expanded", String(open));
    });
    nav.addEventListener("click", function (e) { if (e.target.closest("a")) close(); });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && nav.classList.contains("open")) { close(); burger.focus(); }
    });
    document.addEventListener("click", function (e) {
      if (nav.classList.contains("open") && !e.target.closest(".site-head")) close();
    });
  }

  /* ---------- reveal on scroll ---------- */
  function initReveal() {
    var els = $$(".reveal");
    if (REDUCED || !("IntersectionObserver" in window)) { els.forEach(function (e) { e.classList.add("in"); }); return; }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add("in"); io.unobserve(en.target); }
      });
    }, { threshold: 0.12, rootMargin: "0px 0px -30px 0px" });
    els.forEach(function (e) { io.observe(e); });
  }

  /* ---------- animated counters ---------- */
  function initCounters(scope) {
    $$("[data-count]", scope || document).forEach(function (el) {
      var target = parseInt(el.getAttribute("data-count"), 10) || 0;
      if (REDUCED) { el.textContent = String(target); return; }
      var t0 = null, dur = 900;
      function tick(t) {
        if (!t0) t0 = t;
        var p = Math.min(1, (t - t0) / dur);
        el.textContent = String(Math.round(target * (1 - Math.pow(1 - p, 3))));
        if (p < 1) requestAnimationFrame(tick);
      }
      requestAnimationFrame(tick);
    });
  }

  /* ---------- accordions (event delegation) ---------- */
  function initAccordions() {
    document.addEventListener("click", function (e) {
      var btn = e.target.closest(".acc-btn");
      if (!btn) return;
      var item = btn.closest(".acc-item");
      var wasOpen = item.classList.contains("open");
      var group = btn.closest(".acc");
      var exclusive = group && group.hasAttribute("data-exclusive");
      if (exclusive && group && !wasOpen) {
        $$(".acc-item.open", group).forEach(function (o) { o.classList.remove("open"); $(".acc-btn", o).setAttribute("aria-expanded", "false"); });
      }
      item.classList.toggle("open", !wasOpen);
      btn.setAttribute("aria-expanded", String(!wasOpen));
    });
  }

  /* ---------- source links helper ---------- */
  function refLinks(refs) {
    return '<div class="refs">' + (refs || []).map(function (r) {
      var s = (SITE.sources || {})[r.source] || {};
      return '<a class="ref-link" href="' + esc(s.url || "#") + '" target="_blank" rel="noopener">' + icon("external") + esc(r.label || s.label || "Source") + "</a>";
    }).join("") + "</div>";
  }

  function statusChip(kind) {
    if (kind === "live") return '<span class="chip chip-live">' + icon("check") + "In force now</span>";
    if (kind === "scheduled") return '<span class="chip chip-sched">' + icon("calendar") + "Scheduled — 13 May 2027</span>";
    if (kind === "may2027") return '<span class="chip chip-sched">' + icon("calendar") + "Commences 13 May 2027</span>";
    if (kind === "verified") return '<span class="chip chip-verified">' + icon("shield-check") + "Last verified " + esc(SITE.lastVerified || "") + "</span>";
    if (kind === "past") return '<span class="chip chip-past">' + icon("clock") + "Past milestone</span>";
    return "";
  }

  /* ---------- mini diagrams for "Understand the Act" ---------- */
  var DIAG = {
    scope: function () {
      return '<svg viewBox="0 0 360 330" role="img" aria-label="Applicability flow: is it personal data, is it digital, is it processed in India or offered to people in India. If yes to all, the DPDP Act applies.">' +
        '<defs><marker id="ar1" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0 0L10 5L0 10z" fill="#2BD9EE"/></marker></defs>' +
        ['Is it data about an identifiable person?', 0, 'Is it digital — collected online or later digitised?', 1, 'Processed in India, or offering to people in India?', 2].reduce(function (svg, txt, i) {
          if (i % 2) return svg;
          var y = 22 + (i / 2) * 88;
          return svg + '<rect x="30" y="' + y + '" width="300" height="48" rx="12" fill="rgba(43,217,238,.08)" stroke="rgba(43,217,238,.5)"/>' +
            '<text x="180" y="' + (y + 29) + '" text-anchor="middle" font-size="12.5" fill="#D9E2F5">' + txt + "</text>";
        }, "") +
        '<path d="M180 70v16" stroke="#2BD9EE" stroke-width="2" marker-end="url(#ar1)"/>' +
        '<path d="M180 158v16" stroke="#2BD9EE" stroke-width="2" marker-end="url(#ar1)"/>' +
        '<path d="M180 246v16" stroke="#2BD9EE" stroke-width="2" marker-end="url(#ar1)"/>' +
        '<rect x="55" y="268" width="250" height="46" rx="12" fill="rgba(139,92,246,.18)" stroke="rgba(139,92,246,.65)"/>' +
        '<text x="180" y="296" text-anchor="middle" font-size="13.5" font-weight="700" fill="#fff">The DPDP Act applies</text>' +
        "</svg>";
    },
    roles: function () {
      return '<svg viewBox="0 0 360 300" role="img" aria-label="Roles diagram: Data Principals interact with Data Fiduciaries via consent, requests and Consent Managers. Data Fiduciaries instruct Data Processors and stay accountable for them.">' +
        '<defs><marker id="ar2" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0 0L10 5L0 10z" fill="#93A5CC"/></marker></defs>' +
        '<rect x="20" y="90" width="118" height="64" rx="14" fill="rgba(43,217,238,.1)" stroke="rgba(43,217,238,.55)"/>' +
        '<text x="79" y="117" text-anchor="middle" font-size="12.5" fill="#fff" font-weight="700">Data Principal</text>' +
        '<text x="79" y="135" text-anchor="middle" font-size="10.5" fill="#93A5CC">the person</text>' +
        '<rect x="222" y="90" width="118" height="64" rx="14" fill="rgba(139,92,246,.16)" stroke="rgba(139,92,246,.65)"/>' +
        '<text x="281" y="117" text-anchor="middle" font-size="12.5" fill="#fff" font-weight="700">Data Fiduciary</text>' +
        '<text x="281" y="135" text-anchor="middle" font-size="10.5" fill="#93A5CC">decides purpose</text>' +
        '<rect x="222" y="212" width="118" height="58" rx="14" fill="rgba(147,165,204,.1)" stroke="rgba(147,165,204,.45)"/>' +
        '<text x="281" y="237" text-anchor="middle" font-size="12.5" fill="#D9E2F5" font-weight="700">Data Processor</text>' +
        '<text x="281" y="254" text-anchor="middle" font-size="10.5" fill="#93A5CC">acts on instructions</text>' +
        '<rect x="20" y="212" width="118" height="58" rx="14" fill="rgba(240,169,59,.1)" stroke="rgba(240,169,59,.5)"/>' +
        '<text x="79" y="237" text-anchor="middle" font-size="12.5" fill="#D9E2F5" font-weight="700">Consent Manager</text>' +
        '<text x="79" y="254" text-anchor="middle" font-size="10.5" fill="#93A5CC">registered</text>' +
        '<path d="M142 112h74" stroke="#2BD9EE" stroke-width="2" marker-end="url(#ar2)" marker-start="url(#ar2)"/>' +
        '<text x="180" y="104" text-anchor="middle" font-size="10.5" fill="#2BD9EE">consent · rights</text>' +
        '<path d="M281 158v50" stroke="#93A5CC" stroke-width="2" marker-end="url(#ar2)"/>' +
        '<text x="322" y="187" text-anchor="middle" font-size="10.5" fill="#93A5CC">instructs,</text>' +
        '<text x="322" y="200" text-anchor="middle" font-size="10.5" fill="#93A5CC">accountable</text>' +
        '<path d="M142 236h74" stroke="rgba(240,169,59,.7)" stroke-width="2" stroke-dasharray="4 5" marker-end="url(#ar2)"/>' +
        '<text x="180" y="228" text-anchor="middle" font-size="10.5" fill="#F0A93B">consent choices</text>' +
        '<text x="180" y="30" text-anchor="middle" font-size="11" fill="#93A5CC">The fiduciary stays answerable even when a processor holds the data.</text>' +
        "</svg>";
    },
    security: function () {
      var chips = [["Encryption", 40, 40], ["Access control", 210, 26], ["Logging &amp; monitoring", 232, 128], ["Backups", 48, 150], ["Processor contracts", 96, 222]];
      return '<svg viewBox="0 0 360 286" role="img" aria-label="Reasonable security safeguards orbit the personal data they protect: encryption, access control, logging and monitoring, backups, and processor contracts.">' +
        '<circle cx="180" cy="132" r="58" fill="rgba(43,217,238,.12)" stroke="rgba(43,217,238,.6)"/>' +
        '<text x="180" y="128" text-anchor="middle" font-size="13" font-weight="700" fill="#fff">Personal</text>' +
        '<text x="180" y="146" text-anchor="middle" font-size="13" font-weight="700" fill="#fff">data</text>' +
        chips.map(function (c) {
          return '<rect x="' + c[1] + '" y="' + c[2] + '" width="132" height="38" rx="10" fill="rgba(139,92,246,.14)" stroke="rgba(139,92,246,.55)"/>' +
            '<text x="' + (c[1] + 66) + '" y="' + (c[2] + 24) + '" text-anchor="middle" font-size="11.5" fill="#D9E2F5">' + c[0] + "</text>";
        }).join("") +
        '<path d="M180 74L112 62M180 74l52 -12M180 190l56 -24M180 190l-58 -18M212 222l-14 -32" stroke="rgba(147,165,204,.5)" stroke-width="1.6" stroke-dasharray="3 4"/>' +
        "</svg>";
    }
  };

  /* ================= PAGE RENDERERS ================= */

  /* ----- home ----- */
  function renderHome() {
    var grid = $("#statsGrid");
    if (grid && SITE.home) {
      grid.innerHTML = SITE.home.stats.map(function (s, i) {
        return '<div class="stat reveal d' + (i % 4) + '"><a href="' + esc(s.href || "#") + '">' +
          '<span class="v"' + (s.count ? ' data-count="' + esc(s.value) + '"' : "") + ">" + esc(s.value) + "</span>" +
          '<span class="l">' + esc(s.label) + "</span></a></div>";
      }).join("");
      initCounters(grid);
    }
    var pg = $("#pillarsGrid");
    if (pg && SITE.home) {
      pg.innerHTML = SITE.home.pillars.map(function (p, i) {
        return '<div class="card hoverable reveal d' + i + '"><div class="icon-tile">' + icon(p.icon) + "</div><h3>" +
          esc(p.title) + "</h3><p class=\"card-text\">" + esc(p.text) + "</p></div>";
      }).join("");
    }
    var cd = $("#countdownNum");
    if (cd && SITE.legal) {
      var end = new Date(SITE.legal.mainDutiesISO + "T00:00:00");
      var now = new Date();
      var days = Math.ceil((end - now) / 86400000);
      if (days > 0) cd.textContent = days + (days === 1 ? " day" : " days");
      else cd.textContent = "Commenced";
    }
    var proof = $("#clientProof");
    if (proof && SITE.company) proof.textContent = SITE.company.clientProof;
  }

  /* ----- understand the act ----- */
  function renderAct() {
    var host = $("#actTopics");
    if (!host || !SITE.actTopics) return;
    host.innerHTML = SITE.actTopics.map(function (t, i) {
      var diag = t.diagram && DIAG[t.diagram] ? DIAG[t.diagram]() : "";
      return '<div class="acc-item reveal" id="topic-' + esc(t.id) + '">' +
        '<button class="acc-btn" aria-expanded="false" aria-controls="tp-' + esc(t.id) + '">' +
        '<span class="acc-num" aria-hidden="true">' + (i + 1) + "</span>" +
        icon(t.icon, "ic-lead") +
        '<span class="acc-title">' + esc(t.title) + "</span>" +
        statusChip(t.status) +
        icon("chevron-down", "acc-chev") +
        "</button>" +
        '<div class="acc-panel" id="tp-' + esc(t.id) + '"><div class="acc-panel-in"><div class="acc-body' + (diag ? " has-diagram" : "") + '">' +
        "<div><p class=\"plain\">" + esc(t.plain) + "</p><ul class=\"points\">" +
        t.points.map(function (p) { return "<li>" + esc(p) + "</li>"; }).join("") +
        "</ul>" + (t.nuance ? '<div class="callout">' + icon("info") + "<div><strong>Read this carefully:</strong> " + esc(t.nuance) + "</div></div>" : "") +
        refLinks(t.refs) + "</div>" +
        (diag ? '<figure class="mini-diagram">' + diag + '<figcaption class="mini-cap">Static diagram — readable without any animation.</figcaption></figure>' : "") +
        "</div></div></div></div>";
    }).join("");
    var nav = $("#topicNav");
    if (nav) {
      nav.innerHTML = SITE.actTopics.map(function (t) {
        return '<a class="topic-chip" href="#topic-' + esc(t.id) + '">' + esc(t.title) + "</a>";
      }).join("");
    }
    var firstBtn = $(".acc-item .acc-btn", host);
    if (firstBtn) firstBtn.click();
  }

  /* ----- timeline ----- */
  function renderTimeline() {
    var host = $("#timelineHost");
    if (!host || !SITE.timeline) return;
    var today = SITE.lastVerifiedISO || new Date().toISOString().slice(0, 10);
    var html = "", todayInjected = false;
    SITE.timeline.forEach(function (ev) {
      if (!todayInjected && ev.iso > today) {
        html += todayMarker();
        todayInjected = true;
      }
      html += eventCard(ev);
    });
    if (!todayInjected) html += todayMarker();
    host.innerHTML = html;

    function todayMarker() {
      return '<li class="tl-today" data-status="today">' +
        '<span class="tl-today-badge">' + icon("pin") + esc(SITE.timelineToday.label) + "</span>" +
        '<p class="tl-today-note">' + esc(SITE.timelineToday.note) + "</p></li>";
    }
    function eventCard(ev) {
      var statusIcon = ev.status === "live" ? "check" : ev.status === "scheduled" ? "calendar" : "clock";
      return '<li class="tl-item reveal" data-status="' + esc(ev.status) + '">' +
        '<span class="tl-dot" aria-hidden="true">' + icon(statusIcon) + "</span>" +
        '<div class="tl-card"><span class="tl-date">' + esc(ev.date) + "</span>" +
        '<div style="margin:6px 0 2px">' + statusChip(ev.status) + "</div>" +
        "<h3>" + esc(ev.title) + "</h3><p>" + esc(ev.text) + "</p>" +
        refLinks(ev.refs) + "</div></li>";
    }

    function applyFilter(f) {
      $$(".tl-item", host).forEach(function (li) {
        var s = li.getAttribute("data-status");
        var show = f === "all" || s === f || (f === "scheduled" && s === "today") || (f === "live" && s === "today");
        li.style.display = show ? "" : "none";
      });
      $$(".tl-today", host).forEach(function (li) { li.style.display = ""; });
    }
    $$('input[name="tl-filter"]').forEach(function (r) {
      r.addEventListener("change", function () { applyFilter(r.value); });
    });
  }

  /* ----- services ----- */
  function renderServices() {
    var host = $("#servicesGrid");
    if (!host || !SITE.services) return;
    host.innerHTML = SITE.services.map(function (s, i) {
      return '<div class="card hoverable pen-card reveal d' + (i % 3) + '" style="padding-left:26px">' +
        '<div class="icon-tile">' + icon(s.icon) + "</div>" +
        "<h3>" + esc(s.title) + "</h3>" +
        '<p class="card-text"><strong>The problem:</strong> ' + esc(s.problem) + "</p>" +
        '<p class="card-text" style="margin-bottom:6px"><strong>What you get:</strong></p>' +
        '<ul class="points" style="font-size:.92rem;margin-top:0">' +
        s.deliverables.map(function (d) { return "<li>" + esc(d) + "</li>"; }).join("") + "</ul>" +
        '<a class="more" data-c-href="company.bookingLink" href="resources.html#contact">Discuss in a readiness call ' + icon("arrow-right") + "</a>" +
        "</div>";
    }).join("");
  }

  /* ----- sectors ----- */
  function renderSectors() {
    var tabsHost = $("#sectorTabs"), panelHost = $("#sectorPanels");
    if (!tabsHost || !panelHost || !SITE.sectors) return;
    tabsHost.setAttribute("role", "tablist");
    tabsHost.setAttribute("aria-label", "Sectors");
    tabsHost.innerHTML = SITE.sectors.map(function (s, i) {
      return '<button class="tab" role="tab" id="tab-' + esc(s.id) + '" aria-controls="panel-' + esc(s.id) + '"' +
        ' aria-selected="' + (i === 0 ? "true" : "false") + '" tabindex="' + (i === 0 ? "0" : "-1") + '" data-idx="' + i + '">' +
        icon(s.icon) + esc(s.label) + "</button>";
    }).join("");
    var CAT_SHORT = { security: "security-safeguards failure", notify: "breach-notification failure", children: "children's-data breach", sdf: "SDF-obligations breach", other: "any other breach of the Act or Rules" };
    var panels = SITE.sectors.map(function (s, i) {
      var cat = (SITE.penalties || []).find(function (p) { return p.id === s.penaltyCategory; }) || {};
      var sectorLabel = s.label;
      return '<div class="tabpanel" role="tabpanel" id="panel-' + esc(s.id) + '" aria-labelledby="tab-' + esc(s.id) + '"' +
        (i === 0 ? "" : " hidden") + "><div class=\"sector-grid\">" +
        '<div class="grid" style="gap:18px">' +
        '<div class="card"><h3 style="display:flex;align-items:center;gap:9px">' + icon(s.icon, "ic-lead") + esc(s.label) + " — typical personal-data flows</h3>" +
        '<div class="flows">' + s.flows.map(function (f) { return '<span class="flow-chip">' + icon("database") + esc(f) + "</span>"; }).join("") + "</div></div>" +
        '<div class="card" style="border-color:rgba(146,64,14,.3)"><h3 style="font-size:1.02rem">' + icon("alert", "ic-lead") + " Illustrative failure scenario</h3>" +
        '<p class="card-text" style="margin:0"><em>' + esc(s.scenario) + "</em></p></div>" +
        (s.nuance ? '<div class="callout violet">' + icon("info") + "<div>" + esc(s.nuance) + "</div></div>" : "") +
        "</div>" +
        '<div style="display:grid;gap:18px;align-content:start">' +
        '<div class="duty-card"><h3>Potentially relevant DPDP duty</h3><p style="font-size:.95rem">' + esc(s.duty) + "</p>" +
        '<span class="amount">up to ₹' + esc(cat.amountCr) + " crore</span>" +
        '<span class="penalty-cat">statutory maximum for the <strong>' + esc(CAT_SHORT[s.penaltyCategory] || cat.title) + "</strong> category — not a sector rate, and not a predicted fine</span>" +
        statusChip("may2027") + refLinks([{ label: "DPDP Act and Schedule", source: "act" }, { label: "DPDP Rules, 2025", source: "rules" }]) +
        "</div>" +
        '<div class="addon-card"><span class="draft-tag">Draft add-on — pending confirmation</span>' +
        "<h3 style=\"margin:8px 0 6px\">" + esc(s.addOn.title) + "</h3>" +
        '<p class="card-text" style="margin:0 0 10px">' + esc(s.addOn.text) + "</p>" +
        '<a class="more" data-c-href="company.bookingLink" href="resources.html#contact">Ask about ' + esc(s.addOn.title) + " " + icon("arrow-right") + "</a></div>" +
        "</div></div></div>";
    }).join("");
    panelHost.innerHTML = panels;

    var tabs = $$(".tab", tabsHost);
    function select(idx, focus) {
      tabs.forEach(function (t, i) {
        var on = i === idx;
        t.setAttribute("aria-selected", String(on));
        t.tabIndex = on ? 0 : -1;
        var p = document.getElementById("panel-" + SITE.sectors[i].id);
        if (p) p.hidden = !on;
      });
      if (focus) tabs[idx].focus();
      try { history.replaceState(null, "", "?sector=" + SITE.sectors[idx].id); } catch (e) {}
    }
    tabs.forEach(function (t, i) {
      t.addEventListener("click", function () { select(i); });
      t.addEventListener("keydown", function (e) {
        var d = e.key === "ArrowRight" ? 1 : e.key === "ArrowLeft" ? -1 : e.key === "Home" ? -Infinity : e.key === "End" ? Infinity : 0;
        if (d === 0) return;
        e.preventDefault();
        var n = d === -Infinity ? 0 : d === Infinity ? tabs.length - 1 : (i + d + tabs.length) % tabs.length;
        select(n, true);
      });
    });
    var params = new URLSearchParams(location.search);
    var wanted = params.get("sector");
    var startIdx = 0;
    if (wanted) SITE.sectors.forEach(function (s, i) { if (s.id === wanted) startIdx = i; });
    if (startIdx > 0) select(startIdx);
  }

  /* ----- penalties ----- */
  function renderPenalties() {
    var chartHost = $("#penChart"), cardsHost = $("#penCards");
    if (!chartHost || !cardsHost || !SITE.penalties) return;
    var maxCr = 250;
    var sectorList = SITE.sectors || [];

    chartHost.innerHTML = SITE.penalties.map(function (p) {
      var pct = Math.round((p.amountCr / maxCr) * 100);
      return '<div class="bar-row reveal" data-cat="' + esc(p.id) + '" style="--w:' + pct + '%">' +
        '<div class="bar-label">' + esc(shortTitle(p)) + "</div>" +
        '<div class="bar-track"><div class="bar-fill pre"></div>' +
        '<span class="bar-amount' + (pct > 34 ? " inside" : "") + '">up to ₹' + p.amountCr + " cr</span></div></div>";
    }).join("");

    cardsHost.innerHTML = SITE.penalties.map(function (p, i) {
      var examples = sectorList.map(function (s) {
        var ex = (s.examples || {})[p.id];
        return ex ? '<div class="pen-ex">' + icon("alert") + "<div><span class=\"tag\">" + esc(s.label) + ":</span> " + esc(ex) + "</div></div>" : null;
      }).filter(Boolean).join("");
      return '<div class="card pen-card reveal d' + (i % 3) + '" data-cat="' + esc(p.id) + '" data-all-sectors="' + (examples ? "1" : "0") + '" style="padding-left:26px">' +
        '<div class="icon-tile">' + icon(p.icon) + "</div>" +
        '<h3 style="font-size:1.02rem">' + esc(p.title) + "</h3>" +
        '<span class="pen-amount">₹' + p.amountCr + " cr</span>" +
        '<p class="card-text" style="margin:6px 0 10px">' + esc(p.text) + "</p>" +
        statusChip("may2027") +
        (examples ? '<div class="pen-examples" data-has-ex="1"><h4>Illustrative sector examples <span class="chip" style="font-size:.68rem;padding:2px 8px">illustrative</span></h4>' + examples + "</div>" : '<div class="pen-examples"></div>') +
        "</div>";
    }).join("");

    function shortTitle(p) {
      var map = { security: "Security safeguards failure", notify: "Breach notification failure", children: "Children's data breach", sdf: "SDF obligations breach", other: "Any other breach" };
      return map[p.id] || p.title;
    }

    // filter state
    var fSector = "all", fCat = "all";
    function applyFilters() {
      var summary = $("#filterSummary");
      // bars follow the category filter only
      $$(".bar-row", chartHost).forEach(function (r) {
        r.style.display = (fCat === "all" || r.getAttribute("data-cat") === fCat) ? "" : "none";
      });
      // cards
      $$(".pen-card", cardsHost).forEach(function (c) {
        var catOk = fCat === "all" || c.getAttribute("data-cat") === fCat;
        c.style.display = catOk ? "" : "none";
        var exBox = $(".pen-examples", c);
        if (!exBox) return;
        var wanted = fSector !== "all" ? fSector : null;
        $$(".pen-ex", exBox).forEach(function (ex) { ex.style.display = ""; });
        if (wanted) {
          var any = false;
          $$(".pen-ex", exBox).forEach(function (ex) {
            var isMine = ex.textContent.indexOf((sectorList.find(function (s) { return s.id === wanted; }) || {}).label + ":") === 0;
            ex.style.display = isMine ? "" : "none";
            if (isMine) any = true;
          });
          exBox.style.display = any ? "" : "none";
        } else {
          exBox.style.display = exBox.getAttribute("data-has-ex") ? "" : "none";
        }
      });
      if (summary) {
        var bits = [];
        if (fSector !== "all") bits.push("sector: <strong>" + esc((sectorList.find(function (s) { return s.id === fSector; }) || {}).label) + "</strong>");
        if (fCat !== "all") bits.push("violation type: <strong>" + esc(shortTitle(SITE.penalties.find(function (p) { return p.id === fCat; }) || {})) + "</strong>");
        summary.innerHTML = bits.length ? "Filtering by " + bits.join(" · ") + ". " : "";
        summary.innerHTML += "Remember: these are category maximums, not sector rates or predictions.";
      }
    }
    $$('input[name="f-sector"]').forEach(function (r) { r.addEventListener("change", function () { fSector = r.value; applyFilters(); }); });
    $$('input[name="f-cat"]').forEach(function (r) { r.addEventListener("change", function () { fCat = r.value; applyFilters(); }); });
    applyFilters();

    // animate bars when visible
    if (!REDUCED && "IntersectionObserver" in window) {
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (en) {
          if (en.isIntersecting) {
            var f = $(".bar-fill", en.target);
            if (f) setTimeout(function () { f.classList.remove("pre"); }, 120);
            io.unobserve(en.target);
          }
        });
      }, { threshold: 0.4 });
      $$(".bar-row", chartHost).forEach(function (r) { io.observe(r); });
    } else {
      $$(".bar-fill", chartHost).forEach(function (f) { f.classList.remove("pre"); });
    }

    // schedule table extras
    var sched = $("#scheduleExtra");
    if (sched && SITE.scheduleExtra) {
      sched.innerHTML = SITE.scheduleExtra.map(function (x) {
        return '<tr><td><strong>' + esc(x.title) + "</strong></td><td>" + esc(x.text) + '</td><td class="amt">' + esc(x.amount) + "</td></tr>";
      }).join("");
    }
  }

  /* ----- readiness ----- */
  function renderReadiness() {
    var stepsHost = $("#stepsHost"), panelHost = $("#stepPanels");
    if (stepsHost && panelHost && SITE.journey) {
      stepsHost.innerHTML = SITE.journey.map(function (s, i) {
        return '<button class="step-btn" role="tab" aria-controls="sp-' + i + '" aria-current="' + (i === 0 ? "step" : "false") + '" data-idx="' + i + '" tabindex="0">' +
          '<span class="step-dot">' + (i + 1) + "</span><span class=\"step-name\">" + esc(s.title) + "</span></button>";
      }).join("");
      panelHost.innerHTML = SITE.journey.map(function (s, i) {
        return '<div class="step-panel" id="sp-' + i + '" role="tabpanel"' + (i === 0 ? "" : " hidden") + ">" +
          '<div class="card"><div class="step-cols">' +
          "<div><h3>" + (i + 1) + ". " + esc(s.title) + "</h3>" +
          '<p class="plain" style="color:var(--ink);font-weight:550">' + esc(s.goal) + "</p>" +
          '<ul class="points">' + s.activities.map(function (a) { return "<li>" + esc(a) + "</li>"; }).join("") + "</ul></div>" +
          '<div class="step-out"><span class="k">Typical output</span>' + esc(s.outputs) + "</div>" +
          "</div></div></div>";
      }).join("");
      var btns = $$(".step-btn", stepsHost);
      btns.forEach(function (b, i) {
        b.addEventListener("click", function () { select(i); });
      });
      function select(idx) {
        btns.forEach(function (b, i) {
          b.setAttribute("aria-current", i === idx ? "step" : "false");
          b.classList.toggle("done", i < idx);
          var p = document.getElementById("sp-" + i);
          if (p) p.hidden = i !== idx;
        });
      }
    }

    window.initCyberAssessment();
  }

  /* ----- resources (FAQ, form, privacy) ----- */
  function renderResources() {
    var host = $("#faqHost");
    if (host && SITE.faqs) {
      host.innerHTML = SITE.faqs.map(function (f, i) {
        return '<div class="acc-item reveal"><button class="acc-btn" aria-expanded="false" aria-controls="faq-' + i + '">' +
          '<span class="acc-title">' + esc(f.q) + "</span>" + icon("chevron-down", "acc-chev") + "</button>" +
          '<div class="acc-panel" id="faq-' + i + '"><div class="acc-panel-in"><div class="acc-body"><p style="margin:0;font-size:.96rem">' + esc(f.a) + "</p></div></div></div></div>";
      }).join("");
    }
    var priv = $("#privacyBody");
    if (priv && SITE.privacyNotice) {
      priv.innerHTML = SITE.privacyNotice.paragraphs.map(function (p) { return "<p>" + esc(p) + "</p>"; }).join("");
      var upd = $("#privacyUpdated");
      if (upd) upd.textContent = SITE.privacyNotice.updated;
    }

    // keep FAQ structured data in sync with content.js
    var ld = $('script[type="application/ld+json"]');
    if (ld && SITE.faqs) {
      try {
        var data = JSON.parse(ld.textContent);
        if (data && data["@type"] === "FAQPage") {
          data.mainEntity = SITE.faqs.map(function (f) {
            return { "@type": "Question", name: f.q, acceptedAnswer: { "@type": "Answer", text: f.a } };
          });
          ld.textContent = JSON.stringify(data);
        }
      } catch (e) { /* leave the placeholder JSON-LD as-is */ }
    }

  }

  /* ---------- boot ---------- */
  document.addEventListener("DOMContentLoaded", function () {
    bind();
    initHeader();
    initAccordions();
    var page = document.body.getAttribute("data-page");
    var renderers = {
      home: renderHome, act: renderAct, timeline: renderTimeline,
      services: renderServices, sectors: renderSectors, penalties: renderPenalties,
      readiness: renderReadiness, resources: renderResources
    };
    if (renderers[page]) renderers[page]();
    initReveal();
    markPlaceholders(document.body);
    var yr = $("#year");
    if (yr) yr.textContent = String(new Date().getFullYear());
  });
})();
