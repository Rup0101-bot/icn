/* Browser-local readiness assessment and portable illustrated reports. */
(function () {
  'use strict';
  var extra = [
    ['Cybersecurity', 'Is multi-factor authentication enabled for email, remote access and administrator accounts?', 'Enable MFA on email, VPN, cloud and privileged accounts; record coverage and exceptions.', 3],
    ['Cybersecurity', 'Are access permissions reviewed and leavers removed promptly?', 'Review access quarterly, remove dormant accounts and document joiner, mover and leaver controls.', 4],
    ['Cybersecurity', 'Are operating systems and applications patched within defined risk-based timelines?', 'Inventory missing patches, define deadlines by severity and verify remediation.', 3],
    ['Cybersecurity', 'Is endpoint protection active and monitored on every supported device?', 'Deploy managed endpoint protection and assign an owner to investigate alerts.', 3],
    ['Cybersecurity', 'Are vulnerability scans and penetration tests followed by verified fixes?', 'Schedule authorised vulnerability testing, assign findings and retest fixes.', 1],
    ['Cybersecurity', 'Is sensitive data encrypted in transit and at rest with controlled key access?', 'Review encryption coverage, certificates and key-management permissions.', 2],
    ['Cybersecurity', 'Are security logs centralised, protected and regularly reviewed?', 'Collect key identity, application and system logs; protect them and define alert triage.', 4],
    ['Cybersecurity', 'Are phishing simulations and security awareness sessions run regularly?', 'Train staff to identify phishing and report suspicious messages; track follow-up actions.', 3],
    ['Cybersecurity', 'Are networks segmented and firewall rules reviewed?', 'Separate critical systems and guest networks, restrict exposed services and review firewall rules.', 2],
    ['Cybersecurity', 'Has your team rehearsed a cyber incident with clear escalation contacts?', 'Run a tabletop exercise covering containment, recovery, evidence and escalation.', 4],
    ['IT operations', 'Do you maintain an inventory of devices, software, cloud services and their owners?', 'Create an asset register with owners, versions, support status and criticality.', 0],
    ['IT operations', 'Have backups been restored successfully in a recent recovery test?', 'Test restores, document results and protect an isolated or immutable backup copy.', 4],
    ['IT operations', 'Are recovery-time and recovery-point objectives agreed for critical services?', 'Agree service recovery targets with business owners and test them in a continuity exercise.', 2],
    ['IT operations', 'Are cloud storage, sharing links and configurations checked for public exposure?', 'Review cloud permissions, disable unintended public access and monitor configuration changes.', 1],
    ['IT operations', 'Are production changes approved, tested and supported by rollback plans?', 'Introduce change records with testing evidence, approvals and rollback instructions.', 3],
    ['IT operations', 'Are unsupported systems identified with a replacement or isolation plan?', 'Identify end-of-support technology and assign replacement dates or compensating controls.', 1],
    ['IT operations', 'Are service outages and unusual capacity changes monitored with an on-call owner?', 'Set availability and capacity alerts and test escalation to a named service owner.', 4],
    ['IT operations', 'Are vendor service commitments, security evidence and exit arrangements reviewed?', 'Review critical suppliers, service commitments, security evidence and data-return or deletion plans.', 2],
    ['IT operations', 'Are secure configuration baselines applied to servers, laptops and cloud services?', 'Define hardening baselines, remove defaults and check for configuration drift.', 3],
    ['IT operations', 'Are application secrets stored securely and rotated rather than shared in code?', 'Move secrets into a managed vault, limit access and set rotation and revocation procedures.', 3],
    ["Cyber Insurance", "Has your organisation documented a decision on cyber insurance based on its cyber-risk assessment?", "Document cyber exposures and the decision to seek, retain or decline cyber insurance, with an accountable owner.", 1],
    ["Cyber Insurance", "Do you maintain a current record of any cyber policy, insurer or broker contacts, and renewal dates?", "Maintain a policy register with insurer or broker contacts, policy documents, renewal dates and an owner. Select N/A if you have no policy.", 0],
    ["Cyber Insurance", "Have the scope of cover and relevant exclusions been reviewed against your actual business activities?", "Review policy wording with your broker or insurer against actual business activities; record covered events, exclusions and open questions.", 1],
    ["Cyber Insurance", "Have policy limits, sub-limits and deductibles been compared with your documented loss scenarios?", "Discuss loss scenarios, limits, sub-limits and deductibles with your broker or insurer and document any mismatch.", 2],
    ["Cyber Insurance", "Are answers in insurance proposals and renewals accurate and supported by current security evidence?", "Verify proposal and renewal answers against evidence for MFA, backups, patching and other declared controls; resolve discrepancies before submission.", 4],
    ["Cyber Insurance", "Do you track and maintain security conditions or warranties stated in your policy?", "Record policy security conditions, assign owners and retain evidence that the stated controls remain in place.", 3],
    ["Cyber Insurance", "Does your incident plan include policy-specific notification steps and insurer or broker contacts?", "Add policy notification requirements and current insurer or broker escalation contacts to the incident runbook.", 3],
    ["Cyber Insurance", "Does the response team know when insurer approval or approved response providers may be required?", "Check policy requirements for prior consent, response providers and expenditure approvals; add them to incident procedures.", 2],
    ["Cyber Insurance", "Can you preserve incident evidence and records of costs for a potential claim?", "Define how incident timelines, forensic evidence, invoices and business-interruption records will be preserved for claim review.", 3],
    ["Cyber Insurance", "Are material business or technology changes reviewed with your insurer or broker before renewal?", "Review changes in systems, operations, revenue or data processing against policy disclosure requirements with your insurer or broker.", 4]
  ];
  var colors = ['#06b6d4', '#8b5cf6', '#f59e0b', '#10b981'];
  var cats = ['DPDP', 'Cybersecurity', 'IT operations', 'Cyber Insurance'];
  function esc(s) { return String(s).replace(/[&<>"']/g, function(c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
  window.initCyberAssessment = function () {
    var host = document.getElementById('quizHost'); if (!host) return;
    var questions = window.SITE.assessment.slice(0, 10).map(function(q) { return Object.assign({}, q, {category:'DPDP'}); }).concat(extra.map(function(q) {return {category:q[0],q:q[1],action:q[2],step:q[3]};}));
    var answers = new Array(questions.length).fill(null);
    var result = document.getElementById('quizResult');
    host.innerHTML = '<div class="assessment-progress"><strong id="answerCount">0 / '+questions.length+' answered</strong><progress id="answerProgress" max="'+questions.length+'" value="0" aria-label="Assessment completion"></progress><span>Yes = in place · Partly = needs work · No = gap · N/A = outside your scope</span></div>' + cats.map(function(cat,ci) {
      return '<section class="assessment-domain" style="--domain:'+colors[ci]+'"><h3>'+cat+' <span>'+questions.filter(function(q){return q.category===cat;}).length+' checks</span></h3>'+questions.map(function(q,i) {
        if(q.category!==cat) return '';
        return '<fieldset class="quiz-q" id="check-'+i+'"><legend class="q-text">'+(i+1)+'. '+esc(q.q)+'</legend><div class="opts">'+[['yes','Yes'],['partly','Partly / unsure'],['no','No'],['na','N/A']].map(function(o) { return '<input type="radio" id="check-'+i+'-'+o[0]+'" name="check-'+i+'" value="'+o[0]+'" data-index="'+i+'"><label for="check-'+i+'-'+o[0]+'">'+o[1]+'</label>'; }).join('')+'</div></fieldset>';
      }).join('')+'</section>';
    }).join('');
    host.addEventListener('change', function(e) {
      var i = Number(e.target.dataset.index); if(!Number.isInteger(i)) return;
      answers[i] = e.target.value;
      document.getElementById('check-'+i).classList.remove('unanswered');
      var n=answers.filter(Boolean).length;
      document.getElementById('answerCount').textContent=n+' / '+questions.length+' answered';
      document.getElementById('answerProgress').value=n;
      if(!result.hidden) { result.hidden=true; document.getElementById('quizSubmit').textContent='Update my report'; }
    });
    document.getElementById('quizSubmit').textContent='Generate my FREE report →';
    document.getElementById('quizSubmit').addEventListener('click', function() {
      var first=answers.indexOf(null);
      if(first!==-1) {
        result.hidden=false; result.innerHTML='<p role="alert">Please answer all '+questions.length+' checks. '+answers.filter(function(a){return !a;}).length+' remain. Choose N/A when a check is outside your scope.</p>';
        answers.forEach(function(a,i){document.getElementById('check-'+i).classList.toggle('unanswered',!a);});
        document.querySelector('#check-'+first+' input').focus(); return;
      }
      var totals = ['yes','partly','no','na'].map(function(v){return answers.filter(function(a){return a===v;}).length;});
      var applicable=questions.length-totals[3];
      var percent=applicable ? Math.round(totals[0]/applicable*100) : 0;
      var date=new Date().toLocaleString('en-IN',{timeZone:'Asia/Kolkata',dateStyle:'medium',timeStyle:'short'});
      var svg = chart(totals, percent, applicable);
      var domainSummary = cats.map(function(cat,ci){
        var ids=questions.map(function(q,i){return q.category===cat?i:-1;}).filter(function(i){return i>=0;});
        var counts=['yes','partly','no','na'].map(function(v){return ids.filter(function(i){return answers[i]===v;}).length;});
        return '<div class="domain-stat" style="--domain:'+colors[ci]+'"><strong>'+cat+'</strong><p>'+counts[0]+' in place · '+counts[1]+' partial · '+counts[2]+' gaps · '+counts[3]+' N/A</p></div>';
      }).join('');
      var groups = cats.map(function(cat) {
        var items = questions.map(function(q,i){return {q:q,a:answers[i],i:i};}).filter(function(x){return x.q.category===cat && (x.a==='no'||x.a==='partly');}).sort(function(a,b){return (a.a==='no'?0:1)-(b.a==='no'?0:1);});
        return '<section class="report-group"><h4>'+cat+' — action checklist</h4>'+(items.length? items.map(function(x){return '<label class="check-item"><input type="checkbox"><span><b class="action-priority">'+(x.a==='no'?'Gap':'Partial / unsure')+'</b> '+esc(x.q.action)+'<small>Suggested phase: '+esc(window.SITE.journey[x.q.step].title)+'</small></span></label>';}).join(''):'<p>No gaps reported in this domain. Keep evidence current and validate the answers with your team.</p>')+'</section>';
      }).join('');
      var evidence='<details class="answer-audit"><summary>View all '+questions.length+' answers and verification checks</summary>'+questions.map(function(q,i){return '<p><strong>'+(i+1)+'. '+esc(q.q)+'</strong><br>Answer: '+({yes:'Yes',partly:'Partly / unsure',no:'No',na:'Not applicable'})[answers[i]]+'<br><small>Verify: '+esc(q.action)+'</small></p>';}).join('')+'</details>';
      var report='<div class="report-brand"><img src="'+window.ICN_REPORT_LOGO+'" width="1341" height="800" alt="ICN — Integrated Cyber Nexus"><div><strong>Integrated Cyber Nexus</strong><br><a href="https://icn3.com/">www.icn3.com</a></div></div><div class="report-heading"><p class="eyebrow">CYBER CIBIL · FREE GAP ANALYSIS</p><h3>Your readiness report</h3><p>Generated '+esc(date)+' IST · '+questions.length+' self-reported checks</p></div><div class="gap-overview"><div>'+svg+'</div><div><h4>'+ (applicable?percent+'% of applicable checks reported in place':'No applicable checks selected')+'</h4><p>'+totals[2]+' gaps · '+totals[1]+' partial or unsure · '+totals[0]+' in place · '+totals[3]+' not applicable</p><p class="report-note">This reflects your answers, not an independent audit, certification, legal-compliance score, credit score or fine prediction. N/A answers are excluded from the percentage. Partial answers count as needing attention. Insurance answers assess preparedness only; policy wording and insurer decisions determine coverage and claims.</p>'+domainSummary+'</div></div>'+groups+evidence+'<footer class="report-contact-cta" aria-label="Contact Integrated Cyber Nexus"><p class="report-contact-kicker">YOUR NEXT STEP STARTS HERE</p><h4>Turn your gaps into a stronger defence.</h4><p>Build confidence in your cybersecurity, DPDP readiness, IT operations and cyber insurance preparedness. Talk to Integrated Cybercibil about a practical action plan.</p><a class="report-contact-phone" href="tel:+918777628651">Contact us : +918777628651</a><p class="report-contact-email"><a href="mailto:info@icn3.com?subject=Readiness%20consultation">Email: info@icn3.com</a></p><div class="report-contact-brand">CYBER CIBIL · Integrated Cyber Nexus<br><a href="https://icn3.com/">www.icn3.com</a></div></footer>';
      result.hidden=false; result.innerHTML=report+'<div class="result-actions no-print"><button class="btn btn-primary btn-sm" id="downloadReport">Download visual report</button><button class="btn btn-violet btn-sm" id="printReport">Print / Save PDF</button><button class="btn btn-ghost btn-sm" id="copyReport">Copy checklist</button><span id="reportStatus" role="status"></span></div>';
      result.querySelectorAll('[data-segment]').forEach(function(segment){
        function select(){var i=Number(segment.dataset.segment); result.querySelector('#chartDetail').textContent=['In place','Partial / unsure','Gaps','Not applicable'][i]+': '+totals[i]+' checks';}
        segment.addEventListener('mouseenter',select);segment.addEventListener('focus',select);segment.addEventListener('click',select);segment.addEventListener('keydown',function(e){if(e.key==='Enter'||e.key===' '){e.preventDefault();select();}});
      });
      document.getElementById('downloadReport').onclick=function(){
        var clone=result.cloneNode(true); clone.querySelector('.result-actions').remove();
        clone.querySelector('details').open=true;
        result.querySelectorAll('.check-item input').forEach(function(input,i){if(input.checked)clone.querySelectorAll('.check-item input')[i].setAttribute('checked','');});
        var html='<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Cyber CIBIL Readiness Report</title><style>'+reportStyles+'</style><body><main>'+clone.innerHTML+'</main><button class="no-print" onclick="window.print()">Print / Save PDF</button></body></html>';
        var url=URL.createObjectURL(new Blob([html],{type:'text/html;charset=utf-8'}));var a=document.createElement('a');a.href=url;a.download='cyber-cibil-readiness-report.html';a.click();setTimeout(function(){URL.revokeObjectURL(url);},2000);
        document.getElementById('reportStatus').textContent='Visual report downloaded. Open it to print or save as PDF.';
      };
      document.getElementById('printReport').onclick=function(){window.print();};
      document.getElementById('copyReport').onclick=async function(){try{await navigator.clipboard.writeText(result.innerText.replace(/Download visual report[\s\S]*/,''));document.getElementById('reportStatus').textContent='Checklist copied.';}catch(e){document.getElementById('reportStatus').textContent='Copy unavailable. Please download the report instead.';}};
      result.scrollIntoView({behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'start'});
    });
  };
  function chart(totals,percent,applicable){
    var palette=['#10b981','#f59e0b','#f43f5e','#94a3b8'],labels=['In place','Partial / unsure','Gaps','Not applicable'],offset=0;
    var arcs=totals.map(function(n,i){var length=n/totals.reduce(function(sum,count){return sum+count;},0)*565.487;var arc=n?'<circle data-segment="'+i+'" tabindex="0" role="button" aria-label="'+labels[i]+': '+n+' checks" cx="140" cy="140" r="90" fill="none" stroke="'+palette[i]+'" stroke-width="30" stroke-dasharray="'+length+' '+(565.487-length)+'" stroke-dashoffset="'+(-offset)+'" transform="rotate(-90 140 140)"><title>'+labels[i]+': '+n+' checks</title></circle>':'';offset+=length;return arc;}).join('');
    return '<svg class="gap-donut" viewBox="0 0 280 360" role="group" aria-label="Readiness answer distribution"><circle cx="140" cy="140" r="111" fill="none" stroke="#e2e8f0" stroke-width="1"/>'+arcs+'<text x="140" y="137" text-anchor="middle" fill="#0a1633" font-size="36" font-weight="800">'+(applicable?percent+'%':'N/A')+'</text><text x="140" y="161" text-anchor="middle" fill="#475569" font-size="13">reported in place</text><text id="chartDetail" x="140" y="275" text-anchor="middle" fill="#475569" font-size="13">Explore the colored segments</text>'+labels.map(function(l,i){return '<circle cx="'+(i%2?150:20)+'" cy="'+(305+Math.floor(i/2)*27)+'" r="5" fill="'+palette[i]+'"/><text x="'+(i%2?162:32)+'" y="'+(309+Math.floor(i/2)*27)+'" fill="#334155" font-size="11">'+l+' ('+totals[i]+')</text>';}).join('')+'</svg>';
  }
  var reportStyles='.report-contact-cta{margin-top:32px;padding:28px;border:2px solid #0891b2;border-left:8px solid #7c3aed;border-radius:18px;background:#ecfeff;color:#0a1633;break-inside:avoid;page-break-inside:avoid}.report-contact-cta .report-contact-kicker{margin:0 0 10px;color:#5b2ecc;font-size:11px;font-weight:800;letter-spacing:1.5px}.report-contact-cta h4{margin:0 0 12px;color:#0a1633;font-size:24px;line-height:1.25}.report-contact-cta p{margin:0 0 18px}.report-contact-cta .report-contact-phone{display:block;width:fit-content;max-width:100%;padding:12px 16px;border:1px solid #0e7490;border-radius:10px;background:#0a1633;color:#fff;font-size:19px;font-weight:800;text-decoration:none;overflow-wrap:anywhere}.report-contact-brand{margin-top:18px;font-size:12px;line-height:1.7;color:#334155}.report-contact-brand a{color:#5b2ecc;font-weight:700}@media(max-width:480px){.report-contact-cta{padding:20px}.report-contact-cta h4{font-size:21px}.report-contact-cta .report-contact-phone{font-size:17px;padding:12px}}@media print{.report-contact-cta{display:block!important;break-inside:avoid;page-break-inside:avoid;-webkit-print-color-adjust:exact;print-color-adjust:exact}.report-contact-cta .report-contact-phone{background:#ecfeff!important;color:#0a1633!important;border:2px solid #0e7490}.report-contact-brand a{color:#0a1633!important}}.report-brand{display:flex;align-items:center;gap:20px;flex-wrap:wrap;border-bottom:1px solid #cbd5e1;padding-bottom:20px;margin-bottom:24px;break-inside:avoid}.report-brand img{width:150px;height:auto;max-width:100%;background:white}.report-brand a,.report-brand-footer a{color:#5b2ecc}.report-brand-footer{border-top:1px solid #cbd5e1;padding-top:20px;margin-top:28px;font-size:12px}main>*{min-width:0}body{overflow-wrap:anywhere}.gap-overview{grid-template-columns:minmax(0,300px) minmax(0,1fr)}*{box-sizing:border-box}body{margin:0;padding:36px;font:15px/1.65 system-ui,sans-serif;color:#0a1633;background:#f1f5f9}main{max-width:980px;margin:auto;background:white;padding:40px;border-radius:24px}h3{font-size:32px;margin:0}h4{font-size:19px}.eyebrow{color:#6d28d9;font-weight:bold;letter-spacing:2px}.gap-overview{display:grid;grid-template-columns:300px 1fr;gap:32px;align-items:center}.gap-donut{width:100%;max-width:340px}.domain-stat{border-left:4px solid var(--domain);padding-left:16px;margin:14px 0}.domain-stat p{margin:3px 0}.report-note{color:#475569;font-size:13px}.report-group{border-top:1px solid #cbd5e1;padding:16px 0}.check-item{display:flex;gap:12px;padding:12px 0;break-inside:avoid}.check-item small{display:block;color:#64748b}.action-priority{color:#7c3aed}button{padding:12px 24px;cursor:pointer}details p{break-inside:avoid}@media(max-width:640px){body{padding:12px}main{padding:20px}.gap-overview{grid-template-columns:1fr}}@media print{body{background:white;padding:0}main{padding:0;max-width:none}.no-print{display:none!important}*{-webkit-print-color-adjust:exact;print-color-adjust:exact}svg{break-inside:avoid}details{display:block}details::details-content{content-visibility:visible}}';
})();
